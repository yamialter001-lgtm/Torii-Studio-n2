# Torii TH Image Studio — Personal Manga & Image Translator

A personal, login-free Android image and manga translator modeled on the `toriitranslate.com/image` workflow, translating Japanese, English, Korean, Traditional Chinese, and Simplified Chinese into Thai using your own Gemini API key (`gemini-3.5-flash-lite` primary with automatic `gemini-3.8-flash` fallback) and typesetting directly onto images with `Itim`, `Kodchasan`, and `FiraGO`.

---

## User Review & Critical Decisions

> [!IMPORTANT] **Confirmed Requirements from Clarification**
> All product, API, and visual decisions below reflect your answers and will be built with zero login walls or credit systems.

- **Confirmed Decision 1 — User-Provided Gemini API Key (BYOK)**: You will enter and manage your own Gemini API key directly inside the app's API Key & Model screen (stored locally on-device; no Firebase account, login, or credit balance).
- **Confirmed Decision 2 — Full Torii Image Workspace Scope**: Includes all three feature pillars together: (1) auto-translation onto the image with Before/After comparison (press-and-hold + split slider), (2) an interactive on-image typesetting editor (`Itim`, `Kodchasan`, `FiraGO`, size, color, stroke, alignment, drag/resize, bubble mask fill) with high-resolution gallery export, and (3) multi-image batch selection, sequential queue translation, page filmstrip switching, and batch export.
- **Confirmed Decision 3 — Dual Theme & Translation Mode**: Defaults to a high-contrast Manga Dark Studio palette for comfortable reading, with a quick toggle for Light Studio or System theme, plus selectable **Manga/Comic** vs. **General Image/Sign** translation modes.

---

## 1. Overview & Core Concept

- **What It Does**: Lets you pick single or multiple manga pages, screenshots, or photos from your gallery (using the zero-permission Android Photo Picker), detects speech bubbles and text regions via Gemini multimodal vision, erases/masks original lettering cleanly, and renders editable Thai text directly inside each region with customizable typography and one-tap high-resolution export.
- **Target Audience / Persona**: Personal daily reader and hobbyist translator on Android (phones and tablets/foldables) who wants Torii Image's speed and typesetting control privately on-device with their own Gemini API key.
- **Key Value**: Eliminates browser extensions, logins, and credit limits while giving instant Thai typesetting (`Itim` for casual/handwritten manga dialogue, `Kodchasan` for clean rounded bubbles, `FiraGO` for sharp UI/captions/SFX) and automatic model resilience (`gemini-3.5-flash-lite` -> `gemini-3.8-flash`).

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **First Launch / API Key Gate**: Clean welcome banner prompts once for your Gemini API key (with masked input, paste button, and "Test Key" validation against Gemini). Once saved locally, subsequent launches open straight into the Studio Workspace.
  2. **Import & Queue Setup**: Tap **Import Images** (single or multi-select batch) -> choose source language (`Auto`, `ญี่ปุ่น (JA)`, `อังกฤษ (EN)`, `เกาหลี (KO)`, `จีนตัวเต็ม (ZH-TW)`, `จีนตัวย่อ (ZH-CN)`) and translation mode (`มังงะ/คอมิก` or `ภาพทั่วไป/ป้าย`) -> optionally adjust default font (`Itim`, `Kodchasan`, `FiraGO`).
  3. **Translate & Model Fallback**: Tap **Translate Page** or **Batch Translate All**. A subtle status pill shows the active model (`gemini-3.5-flash-lite`). If the primary model returns a rate limit, timeout, or malformed/empty response, the engine automatically retries with `gemini-3.8-flash` and badges the page accordingly. Context summaries pass from page N to page N+1 in batch mode so character names and pronouns stay consistent.
  4. **Inspect & Compare (Before/After)**: Pinch-to-zoom and pan the canvas smoothly. Hold the **Compare** button for instant original view, or enable **Split Slider** mode to drag a vertical divider comparing raw original text against the Thai typeset result.
  5. **Interactive On-Image Editor**: Tap any translated speech bubble / text box on the canvas to highlight its bounding frame. Drag to reposition, drag corner handles to resize, edit the Thai wording directly, toggle bubble clean-fill style (`Adaptive Fill`, `White Bubble`, `Dark Bubble`, `Blur Patch`), and customize Font (`Itim` / `Kodchasan` / `FiraGO`), Font Size, Text Color, Outline/Stroke width, and Alignment. Also supports adding a manual text box or deleting unwanted detections.
  6. **Export & Local History**: Export the active page or the entire translated batch as full-resolution PNG/JPEG files straight to device storage (`Pictures/ToriiStudioTH`) via MediaStore, or share directly. Projects remain saved locally in Room so you can reopen and re-edit any batch later.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: **Editorial Manga Ink Studio** — focused, distraction-free creative canvas with crisp ink-and-paper contrast so the artwork always stays center stage.
  - *Color Palette & Mood*:
    - **Dark Studio (Default)**: Deep Sumi Charcoal (`background: #0F1115`, `surface: #171A21`, `surfaceVariant: #222631`), Vermilion Torii Accent (`primary: #FF5A36`, `onPrimary: #FFFFFF`), Warm Amber Secondary (`secondary: #FFB84D`), Crisp Paper Text (`onBackground: #F3F4F6`, `onSurfaceVariant: #A0A8B8`).
    - **Light Studio (Toggleable)**: Warm Washi Paper (`background: #FAF8F5`, `surface: #FFFFFF`, `surfaceVariant: #EFECE6`), Deep Torii Vermilion (`primary: #D93E1F`), Ink Charcoal Text (`onBackground: #181A20`).
  - *Typography & Hierarchy*:
    - Bundled locally via `font-util`: **Itim**, **Kodchasan**, and **FiraGO**.
    - App UI uses **FiraGO** for crisp technical controls, model badges, and Thai/English labels, paired with **Kodchasan** for friendly headings and section titles, while **Itim**, **Kodchasan**, and **FiraGO** are all selectable as live canvas typesetting fonts inside every speech bubble.
  - *Component Styling & Layout*:
    - Material 3 adaptive layout: Compact phones use a clean top toolbar (Import, Language/Mode pill, Compare, Export, Settings) + full-bleed zoomable Canvas + collapsible bottom filmstrip / contextual Bubble Inspector sheet. Medium/Expanded tablets place the Batch Filmstrip and Bubble Inspector in a side supporting pane.
    - Minimum 48dp touch targets and edge-to-edge safe insets (`WindowInsets.safeDrawing` / `navigationBarsPadding`).

- **Interactive Feedback & Motion**:
  - Spring-animated bottom inspector sheet (`AnimatedVisibility` + `spring()`) when selecting a text bubble.
  - Shimmering scanline / progress pill during Gemini inference showing current page index (`2/5`) and active model (`3.5-flash-lite` / `3.8-flash` fallback).
  - Haptic/snackbar confirmation on API key verification, image save, and batch completion, plus explicit actionable error banners (never silent failures or mock placeholders).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Direct Gemini REST Client with User Key vs. Firebase AI Logic**:
  - *Chosen Approach*: Direct HTTPS client (Retrofit + OkHttp + Moshi) to `generativelanguage.googleapis.com/v1beta/models/{model}:generateContent` using the user-supplied API key stored locally in DataStore Preferences (obfuscated/private app storage), with zero Firebase Auth or login.
  - *Why*: Matches your explicit choice to enter your own Gemini API key directly in the app for personal use without login or credit systems.
  - *Alternatives Considered*: Firebase AI Logic (`Firebase.ai`) was skipped because you explicitly requested BYOK entry inside the app rather than Firebase project attestation.

- **Decision 2 — Gemini Multimodal Vision + Structured JSON Bounding Boxes + On-Device Canvas Typesetting**:
  - *Chosen Approach*: Send downscaled-yet-sharp page bitmap (preserving aspect ratio, capped safely under payload limits) with a structured JSON `responseSchema` asking Gemini for normalized `[ymin, xmin, ymax, xmax]` (0–1000 scale) regions, source text, Thai translation, background fill hex, text hex, orientation, and region type (`speech`, `narration`, `sfx`), then render and composite everything cleanly on Android `Canvas` / `Bitmap` in Thai using the bundled `Typeface` assets (`Itim`, `Kodchasan`, `FiraGO`).
  - *Why*: Pure image-generation models often corrupt Thai vowels/tone marks (สระ/วรรณยุกต์) and prevent post-editability. Vector/text typesetting over sampled bubble masks guarantees crisp Thai rendering, instant font switching, and full interactive editing.
  - *Alternatives Considered*: On-device ML Kit OCR + text-only translation was rejected because ML Kit lacks strong manga vertical CJK/stylized SFX layout understanding and context-aware bubble grouping that Gemini multimodal handles in a single pass.

- **Decision 3 — Primary + Fallback Model Orchestration (`gemini-3.5-flash-lite` -> `gemini-3.8-flash`)**:
  - *Chosen Approach*: Always attempt `gemini-3.5-flash-lite` first for speed and low token cost; on HTTP 429/5xx, timeout, JSON parse failure, or empty region output (or when user toggles "Force Quality Fallback"), transparently fall back to `gemini-3.8-flash`.
  - *Why*: Delivers fast batch throughput while maintaining high translation accuracy on dense manga pages.

- **Decision 4 — Local Persistence (Room + DataStore) & Zero-Permission Storage**:
  - *Chosen Approach*: Persist translation projects, page records, and edited text boxes locally in Room, store API key, theme, glossary, and defaults in DataStore Preferences, import via Android Photo Picker (`PickMultipleVisualMedia`), and export via `MediaStore` (`Downloads`/`Pictures`).
  - *Why*: Full offline access to past translations without broad storage permissions (`READ_EXTERNAL_STORAGE` / `READ_MEDIA_IMAGES`), compliant with modern Android and Play policies.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         Jetpack Compose UI Layer                          │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌─────────────────┐  │
│  │   Studio Workspace   │  │  Bubble Text Editor  │  │  API & Settings │  │
│  │  - Zoom/Pan Canvas   │  │  - Itim/Kodchasan/   │  │  - BYOK Key     │  │
│  │  - Before/After Split│  │    FiraGO Switcher   │  │  - Model Status │  │
│  │  - Batch Filmstrip   │  │  - Size/Color/Stroke │  │  - Dark/Light   │  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬────────┘  │
└─────────────┼─────────────────────────┼───────────────────────┼───────────┘
              │ StateFlow / Events      │                       │
┌─────────────▼─────────────────────────▼───────────────────────▼───────────┐
│                     StudioViewModel & SettingsViewModel                   │
│  - Batch Queue Orchestrator (Page Context Carryover)                      │
│  - Interactive Selection, Drag/Resize Box State, Undo/Re-translate        │
│  - High-Res Bitmap Exporter (Android Canvas + Typeface Composite)         │
└───────────────────┬───────────────────────────────────┬───────────────────┘
                    │                                   │
┌───────────────────▼───────────────────┐ ┌─────────────▼───────────────────┐
│       GeminiTranslationRepository     │ │     LocalProjectRepository      │
│  - Primary: gemini-3.5-flash-lite     │ │  - Room DB (Projects, Pages,    │
│  - Fallback: gemini-3.8-flash         │ │    Editable TextRegions)        │
│  - Structured JSON Box + Thai Schema  │ │  - DataStore (API Key, Theme,   │
│  - Prompt Builder (Manga vs General)  │ │    Default Font, Glossary)      │
└───────────────────┬───────────────────┘ └─────────────────────────────────┘
                    │ HTTPS (OkHttp + Retrofit + Moshi)
┌───────────────────▼───────────────────────────────────────────────────────┐
│               Google Gemini REST API (generativelanguage v1beta)          │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **TranslationProject**: `id`, `title`, `sourceLanguage` (`AUTO`, `JA`, `EN`, `KO`, `ZH_TW`, `ZH_CN`), `translationMode` (`MANGA`, `GENERAL`), `createdAt`, `glossaryNotes`.
  - **PageItem**: `id`, `projectId`, `pageIndex`, `sourceImagePath` (copied into app-private storage on import so URIs never expire), `width`, `height`, `status` (`PENDING`, `TRANSLATING`, `DONE`, `ERROR`), `modelUsed` (`gemini-3.5-flash-lite` or `gemini-3.8-flash`), `contextSummary`, `errorMessage`.
  - **TextRegion**: `id`, `pageId`, `ymin`, `xmin`, `ymax`, `xmax` (normalized 0f..1000f), `originalText`, `translatedText`, `regionType` (`SPEECH`, `NARRATION`, `SFX`), `fontChoice` (`ITIM`, `KODCHASAN`, `FIRAGO`), `fontSizeSp`, `textColorHex`, `strokeColorHex`, `strokeWidthDp`, `maskColorHex`, `maskStyle` (`SOLID_FILL`, `SOFT_BLUR`, `TRANSPARENT`), `alignment` (`CENTER`, `START`, `END`).
  - **AppPreferences**: `geminiApiKey`, `themeMode` (`DARK`, `LIGHT`, `SYSTEM`), `defaultFont`, `defaultSourceLang`, `defaultMode`, `autoFallbackEnabled`, `customGlossary`.

- **Interactive Component & State Mapping**:
  - *Import Action* -> Photo Picker returns URI list -> copies bitmaps safely into internal project folder -> inserts `PageItem` rows in Room -> automatically opens first page on canvas.
  - *Translate / Batch Translate Action* -> validates non-empty API key (opens API Key dialog if missing) -> iterates pending pages in `viewModelScope` with `withTimeout(60_000L)` -> tries `gemini-3.5-flash-lite`, falls back to `gemini-3.8-flash` on failure -> maps JSON regions into `TextRegion` entities -> saves to Room -> updates UI live as each page completes.
  - *Canvas Tap / Drag / Pinch* -> `detectTapGestures` selects hit `TextRegion` (or clears selection on empty canvas); `detectDragGestures` translates/resizes normalized bounds cleanly clamped to `[0..1000]`; unselected canvas gestures pan & zoom smoothly.
  - *Bubble Inspector Sheet* -> live-binds selected `TextRegion` properties (`translatedText`, `fontChoice`, `fontSizeSp`, `textColor`, `strokeWidth`, `maskStyle`, `alignment`) with immediate canvas preview and persisted Room updates.
  - *Export Action* -> offloads to `Dispatchers.Default`, loads full-resolution original bitmap, draws adaptive bubble masks + Android `StaticLayout` Thai text with exact selected `.ttf` `Typeface` (`Itim`, `Kodchasan`, `FiraGO`) and stroke paint, and saves PNG to `MediaStore.Images.Media` (`Pictures/ToriiStudioTH`).

- **Key Sequences & Integrations**:
  - **Release APK Readiness**: Preserves template `signingConfigs` (`release` and `debugConfig`), uses ProGuard/R8-safe `@JsonClass(generateAdapter = true)` Moshi models so release builds serialize/deserialize reliably, and configures `INTERNET` permission in `AndroidManifest.xml`.
  - **Bundled Fonts**: Installs `Itim`, `Kodchasan`, and `FiraGO` into `app/src/main/res/font/` via `font-util` so both Jetpack Compose UI and Android Canvas `Bitmap` exporter render identical Thai glyphs offline.
