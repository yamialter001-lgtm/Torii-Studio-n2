package com.example.domain.model

import androidx.annotation.FontRes
import com.example.R

enum class SourceLanguage(
    val code: String,
    val labelTh: String,
    val shortLabel: String,
    val promptInstruction: String
) {
    AUTO(
        code = "auto",
        labelTh = "ตรวจจับอัตโนมัติ",
        shortLabel = "Auto",
        promptInstruction = "Auto-detect the source language among Japanese, English, Korean, Traditional Chinese, and Simplified Chinese."
    ),
    JAPANESE(
        code = "ja",
        labelTh = "ญี่ปุ่น",
        shortLabel = "ญี่ปุ่น",
        promptInstruction = "The source text is Japanese (including vertical/horizontal manga text, furigana, and SFX)."
    ),
    ENGLISH(
        code = "en",
        labelTh = "อังกฤษ",
        shortLabel = "อังกฤษ",
        promptInstruction = "The source text is English."
    ),
    KOREAN(
        code = "ko",
        labelTh = "เกาหลี",
        shortLabel = "เกาหลี",
        promptInstruction = "The source text is Korean (manhwa/webtoon speech, narration, and SFX)."
    ),
    TRADITIONAL_CHINESE(
        code = "zh-TW",
        labelTh = "จีนตัวเต็ม",
        shortLabel = "จีนตัวเต็ม",
        promptInstruction = "The source text is Traditional Chinese (manhua/comic vertical or horizontal text)."
    ),
    SIMPLIFIED_CHINESE(
        code = "zh-CN",
        labelTh = "จีนตัวย่อ",
        shortLabel = "จีนตัวย่อ",
        promptInstruction = "The source text is Simplified Chinese."
    );

    companion object {
        fun fromCode(code: String): SourceLanguage =
            entries.firstOrNull { it.code == code } ?: AUTO
    }
}

enum class TranslationMode(
    val id: String,
    val labelTh: String,
    val descriptionTh: String
) {
    MANGA(
        id = "manga",
        labelTh = "มังงะ / คอมิก",
        descriptionTh = "แปลบทสนทนาเป็นภาษาพูดธรรมชาติ รักษาอารมณ์และเสียงเอฟเฟกต์ (SFX)"
    ),
    GENERAL(
        id = "general",
        labelTh = "ภาพทั่วไป / ป้าย",
        descriptionTh = "แปลข้อความ ป้าย หน้าจอ UI หรือเอกสารให้กระชับ ชัดเจน"
    );

    companion object {
        fun fromId(id: String): TranslationMode =
            entries.firstOrNull { it.id == id } ?: MANGA
    }
}

enum class CanvasFont(
    val id: String,
    val displayName: String,
    val subtitleTh: String,
    @param:FontRes val fontRes: Int
) {
    ITIM(
        id = "itim",
        displayName = "Itim",
        subtitleTh = "ลายมืออ่านง่าย เหมาะกับบทพูดมังงะ",
        fontRes = R.font.itim
    ),
    KODCHASAN(
        id = "kodchasan",
        displayName = "Kodchasan",
        subtitleTh = "ทรงกลมสะอาดตา เหมาะกับคำบรรยาย",
        fontRes = R.font.kodchasan
    ),
    FIRAGO(
        id = "firago",
        displayName = "FiraGO",
        subtitleTh = "คมชัดทันสมัย เหมาะกับป้ายและ UI",
        fontRes = R.font.firago
    );

    companion object {
        fun fromId(id: String): CanvasFont =
            entries.firstOrNull { it.id == id } ?: ITIM
    }
}

enum class RegionType(val id: String, val labelTh: String) {
    SPEECH("speech", "บทพูด"),
    NARRATION("narration", "คำบรรยาย"),
    SFX("sfx", "เอฟเฟกต์");

    companion object {
        fun fromId(id: String): RegionType =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: SPEECH
    }
}

enum class MaskStyle(val id: String, val labelTh: String) {
    SOLID_FILL("solid", "เติมสีทึบ"),
    SOFT_BLUR("soft", "ขอบฟุ้งเนียน"),
    TRANSPARENT("transparent", "โปร่งใส");

    companion object {
        fun fromId(id: String): MaskStyle =
            entries.firstOrNull { it.id == id } ?: SOLID_FILL
    }
}

enum class BoxAlignment(val id: String, val labelTh: String) {
    CENTER("center", "กึ่งกลาง"),
    START("start", "ชิดซ้าย"),
    END("end", "ชิดขวา");

    companion object {
        fun fromId(id: String): BoxAlignment =
            entries.firstOrNull { it.id == id } ?: CENTER
    }
}

enum class ThemeMode(val id: String, val labelTh: String) {
    DARK("dark", "โทนมืด (มังงะ)"),
    LIGHT("light", "โทนสว่าง"),
    SYSTEM("system", "ตามระบบ");

    companion object {
        fun fromId(id: String): ThemeMode =
            entries.firstOrNull { it.id == id } ?: DARK
    }
}

enum class PageStatus(val id: String) {
    PENDING("pending"),
    TRANSLATING("translating"),
    DONE("done"),
    ERROR("error");

    companion object {
        fun fromId(id: String): PageStatus =
            entries.firstOrNull { it.id == id } ?: PENDING
    }
}

object GeminiModels {
    const val PRIMARY = "gemini-3.5-flash-lite"
    const val FALLBACK = "gemini-3.8-flash"
}

data class AppPreferences(
    val geminiApiKey: String = "",
    val themeMode: ThemeMode = ThemeMode.DARK,
    val defaultFont: CanvasFont = CanvasFont.ITIM,
    val defaultSourceLanguage: SourceLanguage = SourceLanguage.AUTO,
    val defaultTranslationMode: TranslationMode = TranslationMode.MANGA,
    val autoFallbackEnabled: Boolean = true,
    val customGlossary: String = ""
)

data class TextRegion(
    val id: Long = 0,
    val pageId: Long,
    val ymin: Float,
    val xmin: Float,
    val ymax: Float,
    val xmax: Float,
    val originalText: String,
    val translatedText: String,
    val regionType: RegionType = RegionType.SPEECH,
    val fontChoice: CanvasFont = CanvasFont.ITIM,
    val fontSizeSp: Float = 15f,
    val textColorHex: String = "#111318",
    val strokeColorHex: String = "#FFFFFF",
    val strokeWidthDp: Float = 2.5f,
    val maskColorHex: String = "#FFFFFF",
    val maskStyle: MaskStyle = MaskStyle.SOLID_FILL,
    val alignment: BoxAlignment = BoxAlignment.CENTER
)

data class PageItem(
    val id: Long = 0,
    val projectId: Long,
    val pageIndex: Int,
    val sourceImagePath: String,
    val width: Int,
    val height: Int,
    val status: PageStatus = PageStatus.PENDING,
    val modelUsed: String? = null,
    val contextSummary: String? = null,
    val errorMessage: String? = null,
    val regions: List<TextRegion> = emptyList()
)

data class TranslationProject(
    val id: Long = 0,
    val title: String,
    val sourceLanguage: SourceLanguage,
    val translationMode: TranslationMode,
    val glossaryNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val pages: List<PageItem> = emptyList()
)
