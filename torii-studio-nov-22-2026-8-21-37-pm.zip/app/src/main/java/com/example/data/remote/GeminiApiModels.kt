package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiGenerateRequest(
    @param:Json(name = "contents") val contents: List<ContentPayload>,
    @param:Json(name = "systemInstruction") val systemInstruction: ContentPayload? = null,
    @param:Json(name = "generationConfig") val generationConfig: GenerationConfigPayload? = null,
    @param:Json(name = "safetySettings") val safetySettings: List<SafetySettingPayload>? = null
)

@JsonClass(generateAdapter = true)
data class ContentPayload(
    @param:Json(name = "role") val role: String? = null,
    @param:Json(name = "parts") val parts: List<PartPayload>
)

@JsonClass(generateAdapter = true)
data class PartPayload(
    @param:Json(name = "text") val text: String? = null,
    @param:Json(name = "inlineData") val inlineData: InlineDataPayload? = null
)

@JsonClass(generateAdapter = true)
data class InlineDataPayload(
    @param:Json(name = "mimeType") val mimeType: String,
    @param:Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfigPayload(
    @param:Json(name = "temperature") val temperature: Double = 0.2,
    @param:Json(name = "maxOutputTokens") val maxOutputTokens: Int? = null,
    @param:Json(name = "responseMimeType") val responseMimeType: String? = null,
    @param:Json(name = "responseSchema") val responseSchema: SchemaNode? = null
)

@JsonClass(generateAdapter = true)
data class SchemaNode(
    @param:Json(name = "type") val type: String,
    @param:Json(name = "description") val description: String? = null,
    @param:Json(name = "properties") val properties: Map<String, SchemaNode>? = null,
    @param:Json(name = "required") val required: List<String>? = null,
    @param:Json(name = "items") val items: SchemaNode? = null,
    @param:Json(name = "enum") val enumValues: List<String>? = null
)

@JsonClass(generateAdapter = true)
data class SafetySettingPayload(
    @param:Json(name = "category") val category: String,
    @param:Json(name = "threshold") val threshold: String
)

@JsonClass(generateAdapter = true)
data class GeminiGenerateResponse(
    @param:Json(name = "candidates") val candidates: List<CandidateResponse>? = null,
    @param:Json(name = "error") val error: GeminiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class CandidateResponse(
    @param:Json(name = "content") val content: ContentPayload? = null,
    @param:Json(name = "finishReason") val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiErrorEnvelope(
    @param:Json(name = "error") val error: GeminiErrorDetail? = null
)

@JsonClass(generateAdapter = true)
data class GeminiErrorDetail(
    @param:Json(name = "code") val code: Int? = null,
    @param:Json(name = "message") val message: String? = null,
    @param:Json(name = "status") val status: String? = null
)

@JsonClass(generateAdapter = true)
data class TranslatedPagePayload(
    @param:Json(name = "pageSummary") val pageSummary: String? = null,
    @param:Json(name = "regions") val regions: List<TranslatedRegionPayload> = emptyList()
)

@JsonClass(generateAdapter = true)
data class TranslatedRegionPayload(
    @param:Json(name = "ymin") val ymin: Float = 0f,
    @param:Json(name = "xmin") val xmin: Float = 0f,
    @param:Json(name = "ymax") val ymax: Float = 0f,
    @param:Json(name = "xmax") val xmax: Float = 0f,
    @param:Json(name = "originalText") val originalText: String = "",
    @param:Json(name = "translatedText") val translatedText: String = "",
    @param:Json(name = "regionType") val regionType: String = "speech",
    @param:Json(name = "maskColorHex") val maskColorHex: String = "#FFFFFF",
    @param:Json(name = "textColorHex") val textColorHex: String = "#111318",
    @param:Json(name = "strokeColorHex") val strokeColorHex: String = "#FFFFFF",
    @param:Json(name = "suggestedFontSize") val suggestedFontSize: Float = 15f
)
