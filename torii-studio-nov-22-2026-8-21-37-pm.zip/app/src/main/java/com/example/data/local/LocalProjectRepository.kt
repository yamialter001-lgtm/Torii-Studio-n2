package com.example.data.local

import android.net.Uri
import com.example.domain.model.CanvasFont
import com.example.domain.model.PageStatus
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TextRegion
import com.example.domain.model.TranslationMode
import com.example.domain.model.TranslationProject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalProjectRepository(
    private val dao: StudioDao,
    private val imageStorage: ImageStorageManager
) {
    fun observeProjects(): Flow<List<TranslationProject>> =
        dao.observeProjects().map { list -> list.map { it.toDomain() } }

    fun observeProject(projectId: Long): Flow<TranslationProject?> =
        dao.observeProject(projectId).map { it?.toDomain() }

    suspend fun getProjectOnce(projectId: Long): TranslationProject? =
        dao.getProjectOnce(projectId)?.toDomain()

    suspend fun createProjectWithImages(
        title: String,
        sourceLanguage: SourceLanguage,
        translationMode: TranslationMode,
        glossaryNotes: String,
        uris: List<Uri>
    ): Long {
        val now = System.currentTimeMillis()
        val projectId = dao.insertProject(
            ProjectEntity(
                title = title,
                sourceLanguage = sourceLanguage.code,
                translationMode = translationMode.id,
                glossaryNotes = glossaryNotes,
                createdAt = now,
                updatedAt = now
            )
        )
        val pageEntities = uris.mapIndexed { idx, uri ->
            val imported = imageStorage.importImageFromUri(uri)
            PageEntity(
                projectId = projectId,
                pageIndex = idx,
                sourceImagePath = imported.filePath,
                width = imported.width,
                height = imported.height,
                status = PageStatus.PENDING.id
            )
        }
        dao.insertPages(pageEntities)
        return projectId
    }

    suspend fun appendImagesToProject(projectId: Long, existingCount: Int, uris: List<Uri>) {
        val pageEntities = uris.mapIndexed { idx, uri ->
            val imported = imageStorage.importImageFromUri(uri)
            PageEntity(
                projectId = projectId,
                pageIndex = existingCount + idx,
                sourceImagePath = imported.filePath,
                width = imported.width,
                height = imported.height,
                status = PageStatus.PENDING.id
            )
        }
        dao.insertPages(pageEntities)
        dao.touchProject(projectId)
    }

    suspend fun updateProjectConfig(
        projectId: Long,
        sourceLanguage: SourceLanguage,
        mode: TranslationMode
    ) {
        dao.updateProjectConfig(projectId, sourceLanguage.code, mode.id)
    }

    suspend fun markPageTranslating(pageId: Long) {
        dao.updatePageTranslationResult(
            pageId = pageId,
            status = PageStatus.TRANSLATING.id,
            modelUsed = null,
            contextSummary = null,
            errorMessage = null
        )
    }

    suspend fun savePageTranslationSuccess(
        projectId: Long,
        pageId: Long,
        modelUsed: String,
        contextSummary: String?,
        regions: List<TextRegion>
    ) {
        dao.replaceRegionsForPage(
            pageId = pageId,
            status = PageStatus.DONE.id,
            modelUsed = modelUsed,
            contextSummary = contextSummary,
            errorMessage = null,
            regions = regions.map { it.copy(pageId = pageId).toEntity() }
        )
        dao.touchProject(projectId)
    }

    suspend fun savePageTranslationError(pageId: Long, message: String) {
        dao.updatePageTranslationResult(
            pageId = pageId,
            status = PageStatus.ERROR.id,
            modelUsed = null,
            contextSummary = null,
            errorMessage = message
        )
    }

    suspend fun updateRegion(region: TextRegion) {
        dao.updateRegion(region.toEntity())
    }

    suspend fun addRegion(region: TextRegion): Long {
        return dao.insertRegion(region.toEntity())
    }

    suspend fun deleteRegion(regionId: Long) {
        dao.deleteRegion(regionId)
    }

    suspend fun applyFontToPage(pageId: Long, font: CanvasFont) {
        dao.updateAllRegionsFontOnPage(pageId, font.id)
    }

    suspend fun deleteProject(project: TranslationProject) {
        project.pages.forEach { page ->
            imageStorage.deleteImageFile(page.sourceImagePath)
        }
        dao.deleteProject(project.id)
    }
}
