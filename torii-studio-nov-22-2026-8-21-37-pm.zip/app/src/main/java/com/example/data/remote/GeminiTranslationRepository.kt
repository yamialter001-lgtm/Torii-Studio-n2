package com.example.data.remote

import android.util.Base64
import android.util.Log
import com.example.data.local.ImageStorageManager
import com.example.domain.model.BoxAlignment
import com.example.domain.model.CanvasFont
import com.example.domain.model.GeminiModels
import com.example.domain.model.MaskStyle
import com.example.domain.model.RegionType
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TextRegion
import com.example.domain.model.TranslationMode
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

data class PageTranslationOutput(
    val regions: List<TextRegion>,
    val modelUsed: String,
    val usedFallback: Boolean,
    val contextSummary: String?
)

sealed class KeyValidationResult {
    data class Valid(val modelVerified: String) : KeyValidationResult()
    data class Invalid(val message: String) : KeyValidationResult()
}

class GeminiException(
    val httpCode: Int?,
    val isAuthError: Boolean,
    override val message: String
) : Exception(message)

class GeminiTranslationRepository(
    private val imageStorage: ImageStorageManager
) {
    companion object {
        private const val TAG = "GeminiRepo"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"
        private const val REQUEST_TIMEOUT_MS = 60_000L
    }

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val pagePayloadAdapter by lazy {
        moshi.adapter(TranslatedPagePayload::class.java)
    }

    private val errorEnvelopeAdapter by lazy {
        moshi.adapter(GeminiErrorEnvelope::class.java)
    }

    private val service: GeminiApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    suspend fun validateApiKey(rawKey: String): KeyValidationResult {
        val apiKey = rawKey.trim()
        if (apiKey.isEmpty()) {
            return KeyValidationResult.Invalid("กรุณากรอก Gemini API Key ก่อนตรวจสอบ")
        }

        val testBody = GeminiGenerateRequest(
            contents = listOf(
                ContentPayload(
                    role = "user",
                    parts = listOf(PartPayload(text = "Reply with OK"))
                )
            ),
            generationConfig = GenerationConfigPayload(
                temperature = 0.0,
                maxOutputTokens = 8
            )
        )

        return try {
            withTimeout(25_000L) {
                try {
                    val primaryResp = service.generateContent(GeminiModels.PRIMARY, apiKey, testBody)
                    if (primaryResp.isSuccessful) {
                        KeyValidationResult.Valid(GeminiModels.PRIMARY)
                    } else {
                        val err = parseError(primaryResp.code(), primaryResp.errorBody()?.string())
                        if (err.isAuthError) {
                            KeyValidationResult.Invalid(err.message)
                        } else {
                            // Try fallback model to see if key works on gemini-3.8-flash
                            val fallbackResp = service.generateContent(GeminiModels.FALLBACK, apiKey, testBody)
                            if (fallbackResp.isSuccessful) {
                                KeyValidationResult.Valid(GeminiModels.FALLBACK)
                            } else {
                                val fallbackErr = parseError(
                                    fallbackResp.code(),
                                    fallbackResp.errorBody()?.string()
                                )
                                KeyValidationResult.Invalid(fallbackErr.message)
                            }
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    KeyValidationResult.Invalid(e.localizedMessage ?: "เชื่อมต่อ Gemini API ไม่สำเร็จ")
                }
            }
        } catch (e: TimeoutCancellationException) {
            KeyValidationResult.Invalid("หมดเวลาเชื่อมต่อ (Timeout) กรุณาตรวจสอบอินเทอร์เน็ต")
        }
    }

    suspend fun translatePage(
        apiKey: String,
        imagePath: String,
        pageId: Long,
        sourceLanguage: SourceLanguage,
        translationMode: TranslationMode,
        defaultFont: CanvasFont,
        customGlossary: String,
        previousPageContext: String?,
        autoFallbackEnabled: Boolean,
        forcedModel: String? = null
    ): PageTranslationOutput {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            throw GeminiException(
                httpCode = null,
                isAuthError = true,
                message = "ยังไม่ได้ตั้งค่า Gemini API Key กรุณากรอกคีย์ในเมนูตั้งค่า"
            )
        }

        val jpegBytes = imageStorage.encodeBitmapForGemini(imagePath, maxDimension = 1600)
        val base64Image = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)

        val request = buildTranslationRequest(
            base64Image = base64Image,
            sourceLanguage = sourceLanguage,
            translationMode = translationMode,
            customGlossary = customGlossary,
            previousPageContext = previousPageContext
        )

        val primaryModel = forcedModel ?: GeminiModels.PRIMARY

        return try {
            val payload = invokeModelWithTimeout(primaryModel, cleanKey, request)
            mapPayloadToOutput(
                payload = payload,
                pageId = pageId,
                defaultFont = defaultFont,
                modelUsed = primaryModel,
                usedFallback = false
            )
        } catch (e: CancellationException) {
            throw e
        } catch (primaryErr: Exception) {
            Log.e(TAG, "Primary model $primaryModel failed: ${primaryErr.message}", primaryErr)
            val isAuth = (primaryErr as? GeminiException)?.isAuthError == true
            val canFallback = forcedModel == null && autoFallbackEnabled && !isAuth

            if (!canFallback) {
                throw primaryErr
            }

            try {
                Log.i(TAG, "Falling back to ${GeminiModels.FALLBACK}")
                val fallbackPayload = invokeModelWithTimeout(GeminiModels.FALLBACK, cleanKey, request)
                mapPayloadToOutput(
                    payload = fallbackPayload,
                    pageId = pageId,
                    defaultFont = defaultFont,
                    modelUsed = GeminiModels.FALLBACK,
                    usedFallback = true
                )
            } catch (e: CancellationException) {
                throw e
            } catch (fallbackErr: Exception) {
                Log.e(TAG, "Fallback model ${GeminiModels.FALLBACK} failed: ${fallbackErr.message}", fallbackErr)
                throw GeminiException(
                    httpCode = (fallbackErr as? GeminiException)?.httpCode,
                    isAuthError = (fallbackErr as? GeminiException)?.isAuthError ?: false,
                    message = "โมเดลหลัก ($primaryModel) และโมเดลสำรอง (${GeminiModels.FALLBACK}) ล้มเหลว: ${fallbackErr.message}"
                )
            }
        }
    }

    private suspend fun invokeModelWithTimeout(
        model: String,
        apiKey: String,
        request: GeminiGenerateRequest
    ): TranslatedPagePayload {
        return try {
            withTimeout(REQUEST_TIMEOUT_MS) {
                val response = service.generateContent(model, apiKey, request)
                if (!response.isSuccessful) {
                    throw parseError(response.code(), response.errorBody()?.string())
                }
                val body = response.body()
                    ?: throw GeminiException(response.code(), false, "Gemini API ส่งข้อมูลว่างกลับมา")

                val rawJson = body.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.firstOrNull { !it.text.isNullOrBlank() }
                    ?.text
                    ?: throw GeminiException(null, false, "ไม่พบผลลัพธ์ข้อความจากโมเดล $model")

                val parsed = pagePayloadAdapter.fromJson(rawJson)
                    ?: throw GeminiException(null, false, "รูปแบบ JSON จากโมเดล $model ไม่สมบูรณ์")
                parsed
            }
        } catch (e: TimeoutCancellationException) {
            throw GeminiException(null, false, "การแปลด้วย $model เกินเวลา 60 วินาที")
        }
    }

    private fun mapPayloadToOutput(
        payload: TranslatedPagePayload,
        pageId: Long,
        defaultFont: CanvasFont,
        modelUsed: String,
        usedFallback: Boolean
    ): PageTranslationOutput {
        val regions = payload.regions.mapNotNull { item ->
            val cleanText = item.translatedText.trim()
            if (cleanText.isEmpty()) return@mapNotNull null

            val ymin = item.ymin.coerceIn(0f, 990f)
            val xmin = item.xmin.coerceIn(0f, 990f)
            val ymax = item.ymax.coerceIn(ymin + 12f, 1000f)
            val xmax = item.xmax.coerceIn(xmin + 12f, 1000f)

            val regionType = RegionType.fromId(item.regionType)
            val isSfx = regionType == RegionType.SFX
            val fontSize = item.suggestedFontSize.takeIf { it in 9f..36f } ?: if (isSfx) 17f else 14.5f

            TextRegion(
                pageId = pageId,
                ymin = ymin,
                xmin = xmin,
                ymax = ymax,
                xmax = xmax,
                originalText = item.originalText.trim(),
                translatedText = cleanText,
                regionType = regionType,
                fontChoice = defaultFont,
                fontSizeSp = fontSize,
                textColorHex = normalizeHex(item.textColorHex, "#111318"),
                strokeColorHex = normalizeHex(item.strokeColorHex, "#FFFFFF"),
                strokeWidthDp = if (isSfx) 3.5f else 2.2f,
                maskColorHex = normalizeHex(item.maskColorHex, "#FFFFFF"),
                maskStyle = if (isSfx) MaskStyle.SOFT_BLUR else MaskStyle.SOLID_FILL,
                alignment = BoxAlignment.CENTER
            )
        }

        return PageTranslationOutput(
            regions = regions,
            modelUsed = modelUsed,
            usedFallback = usedFallback,
            contextSummary = payload.pageSummary?.trim()?.takeIf { it.isNotEmpty() }
        )
    }

    private fun buildTranslationRequest(
        base64Image: String,
        sourceLanguage: SourceLanguage,
        translationMode: TranslationMode,
        customGlossary: String,
        previousPageContext: String?
    ): GeminiGenerateRequest {
        val modeGuidance = when (translationMode) {
            TranslationMode.MANGA -> """
                Mode: MANGA / COMIC / WEBTOON.
                - Group text naturally by speech bubble, narration box, or distinct SFX cluster (do NOT split one speech bubble into separate lines).
                - Translate into natural, expressive Thai spoken dialogue fitting the character's tone, emotion, and relationship.
                - For sound effects (regionType = "sfx"), translate or adapt into vivid Thai onomatopoeia (e.g., ตึง!, ฟิ้ว!, ซ่า!).
                - Preserve vertical/horizontal bubble coverage accurately so the original text is cleanly covered.
            """.trimIndent()

            TranslationMode.GENERAL -> """
                Mode: GENERAL IMAGE / UI / SIGN / DOCUMENT.
                - Detect every distinct text block, sign, menu label, or caption.
                - Translate accurately into clear, concise, natural Thai.
                - Match the background color (`maskColorHex`) and text color (`textColorHex`) closely to the surface behind each text block.
            """.trimIndent()
        }

        val glossarySection = if (customGlossary.isNotBlank()) {
            "\nCustom Glossary & Style Rules (strictly follow):\n$customGlossary"
        } else {
            ""
        }

        val continuitySection = if (!previousPageContext.isNullOrBlank()) {
            "\nPrevious Page Context (keep character names, pronouns, and terminology consistent):\n$previousPageContext"
        } else {
            ""
        }

        val systemText = """
            You are Torii TH Studio, an expert visual translator and manga typesetter translating ${sourceLanguage.promptInstruction} into Thai (ภาษาไทย).
            $modeGuidance
            $glossarySection
            $continuitySection

            Bounding Box Rules:
            - Use normalized integer/float coordinates from 0 to 1000 (`ymin`, `xmin`, `ymax`, `xmax`) relative to image height and width.
            - Make each bounding box fit tightly inside the interior of the speech bubble or text region so filling it with `maskColorHex` cleanly covers all original text without spilling over dark bubble borders.
            - Provide `maskColorHex` (e.g. "#FFFFFF" for white bubbles, "#121318" for dark bubbles/boxes), `textColorHex` with strong readability contrast against `maskColorHex`, and `strokeColorHex` matching `maskColorHex` (or contrasting outline for SFX).
            - Provide `suggestedFontSize` between 11 and 26 based on bubble size and text length.
            - If the image has NO translatable text, return an empty `regions` array.
        """.trimIndent()

        val regionSchema = SchemaNode(
            type = "OBJECT",
            properties = mapOf(
                "ymin" to SchemaNode(type = "NUMBER", description = "Top edge 0..1000"),
                "xmin" to SchemaNode(type = "NUMBER", description = "Left edge 0..1000"),
                "ymax" to SchemaNode(type = "NUMBER", description = "Bottom edge 0..1000"),
                "xmax" to SchemaNode(type = "NUMBER", description = "Right edge 0..1000"),
                "originalText" to SchemaNode(type = "STRING", description = "Detected original text"),
                "translatedText" to SchemaNode(type = "STRING", description = "Natural Thai translation"),
                "regionType" to SchemaNode(
                    type = "STRING",
                    enumValues = listOf("speech", "narration", "sfx")
                ),
                "maskColorHex" to SchemaNode(type = "STRING", description = "Hex color of bubble background"),
                "textColorHex" to SchemaNode(type = "STRING", description = "Hex color for Thai text"),
                "strokeColorHex" to SchemaNode(type = "STRING", description = "Hex color for text outline"),
                "suggestedFontSize" to SchemaNode(type = "NUMBER", description = "Suggested font size 11..26")
            ),
            required = listOf(
                "ymin", "xmin", "ymax", "xmax",
                "originalText", "translatedText", "regionType",
                "maskColorHex", "textColorHex", "strokeColorHex"
            )
        )

        val rootSchema = SchemaNode(
            type = "OBJECT",
            properties = mapOf(
                "pageSummary" to SchemaNode(
                    type = "STRING",
                    description = "Brief 1-sentence summary in Thai/English of speakers and tone for next-page continuity"
                ),
                "regions" to SchemaNode(
                    type = "ARRAY",
                    items = regionSchema
                )
            ),
            required = listOf("regions")
        )

        return GeminiGenerateRequest(
            systemInstruction = ContentPayload(parts = listOf(PartPayload(text = systemText))),
            contents = listOf(
                ContentPayload(
                    role = "user",
                    parts = listOf(
                        PartPayload(
                            inlineData = InlineDataPayload(
                                mimeType = "image/jpeg",
                                data = base64Image
                            )
                        ),
                        PartPayload(
                            text = "Detect all text regions in this image and translate them into natural Thai JSON following the schema."
                        )
                    )
                )
            ),
            generationConfig = GenerationConfigPayload(
                temperature = 0.2,
                responseMimeType = "application/json",
                responseSchema = rootSchema
            ),
            safetySettings = listOf(
                SafetySettingPayload("HARM_CATEGORY_HARASSMENT", "BLOCK_ONLY_HIGH"),
                SafetySettingPayload("HARM_CATEGORY_HATE_SPEECH", "BLOCK_ONLY_HIGH"),
                SafetySettingPayload("HARM_CATEGORY_SEXUALLY_EXPLICIT", "BLOCK_ONLY_HIGH"),
                SafetySettingPayload("HARM_CATEGORY_DANGEROUS_CONTENT", "BLOCK_ONLY_HIGH")
            )
        )
    }

    private fun parseError(code: Int, rawBody: String?): GeminiException {
        val detailMessage = rawBody?.let {
            runCatching { errorEnvelopeAdapter.fromJson(it)?.error?.message }.getOrNull()
        }
        val isAuth = code == 400 && (detailMessage?.contains("API key", ignoreCase = true) == true) ||
            code == 401 || code == 403

        val friendlyMessage = when {
            isAuth -> "Gemini API Key ไม่ถูกต้องหรือถูกปิดใช้งาน (${detailMessage ?: "HTTP $code"})"
            code == 429 -> "เกินขีดจำกัดการใช้งานชั่วคราว (Rate Limit HTTP 429)"
            code == 404 -> "ไม่พบโมเดลที่เรียกใช้งาน (HTTP 404)"
            code >= 500 -> "เซิร์ฟเวอร์ Gemini ขัดข้องชั่วคราว (HTTP $code)"
            !detailMessage.isNullOrBlank() -> "$detailMessage (HTTP $code)"
            else -> "เกิดข้อผิดพลาดในการเชื่อมต่อ Gemini (HTTP $code)"
        }
        return GeminiException(httpCode = code, isAuthError = isAuth, message = friendlyMessage)
    }

    private fun normalizeHex(raw: String?, fallback: String): String {
        val candidate = raw?.trim().orEmpty()
        return if (Regex("^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$").matches(candidate)) {
            candidate.uppercase()
        } else {
            fallback
        }
    }
}
