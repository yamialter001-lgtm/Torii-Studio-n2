package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudioDao {
    @Transaction
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeProjects(): Flow<List<ProjectWithPages>>

    @Transaction
    @Query("SELECT * FROM projects WHERE id = :projectId")
    fun observeProject(projectId: Long): Flow<ProjectWithPages?>

    @Transaction
    @Query("SELECT * FROM projects WHERE id = :projectId")
    suspend fun getProjectOnce(projectId: Long): ProjectWithPages?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("UPDATE projects SET sourceLanguage = :sourceLang, translationMode = :mode, updatedAt = :updatedAt WHERE id = :projectId")
    suspend fun updateProjectConfig(projectId: Long, sourceLang: String, mode: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE projects SET updatedAt = :updatedAt WHERE id = :projectId")
    suspend fun touchProject(projectId: Long, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProject(projectId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: PageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<PageEntity>): List<Long>

    @Query("UPDATE pages SET status = :status, modelUsed = :modelUsed, contextSummary = :contextSummary, errorMessage = :errorMessage WHERE id = :pageId")
    suspend fun updatePageTranslationResult(
        pageId: Long,
        status: String,
        modelUsed: String?,
        contextSummary: String?,
        errorMessage: String?
    )

    @Query("DELETE FROM pages WHERE id = :pageId")
    suspend fun deletePage(pageId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegion(region: TextRegionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegions(regions: List<TextRegionEntity>)

    @Update
    suspend fun updateRegion(region: TextRegionEntity)

    @Query("UPDATE text_regions SET fontChoice = :fontChoice WHERE pageId = :pageId")
    suspend fun updateAllRegionsFontOnPage(pageId: Long, fontChoice: String)

    @Query("DELETE FROM text_regions WHERE pageId = :pageId")
    suspend fun deleteRegionsForPage(pageId: Long)

    @Query("DELETE FROM text_regions WHERE id = :regionId")
    suspend fun deleteRegion(regionId: Long)

    @Transaction
    suspend fun replaceRegionsForPage(
        pageId: Long,
        status: String,
        modelUsed: String?,
        contextSummary: String?,
        errorMessage: String?,
        regions: List<TextRegionEntity>
    ) {
        updatePageTranslationResult(pageId, status, modelUsed, contextSummary, errorMessage)
        deleteRegionsForPage(pageId)
        if (regions.isNotEmpty()) {
            insertRegions(regions)
        }
    }
}
