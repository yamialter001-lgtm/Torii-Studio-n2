package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.example.domain.model.BoxAlignment
import com.example.domain.model.CanvasFont
import com.example.domain.model.MaskStyle
import com.example.domain.model.PageItem
import com.example.domain.model.PageStatus
import com.example.domain.model.RegionType
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TextRegion
import com.example.domain.model.TranslationMode
import com.example.domain.model.TranslationProject

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceLanguage: String,
    val translationMode: String,
    val glossaryNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "pages",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class PageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val pageIndex: Int,
    val sourceImagePath: String,
    val width: Int,
    val height: Int,
    val status: String,
    val modelUsed: String? = null,
    val contextSummary: String? = null,
    val errorMessage: String? = null
)

@Entity(
    tableName = "text_regions",
    foreignKeys = [
        ForeignKey(
            entity = PageEntity::class,
            parentColumns = ["id"],
            childColumns = ["pageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("pageId")]
)
data class TextRegionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pageId: Long,
    val ymin: Float,
    val xmin: Float,
    val ymax: Float,
    val xmax: Float,
    val originalText: String,
    val translatedText: String,
    val regionType: String,
    val fontChoice: String,
    val fontSizeSp: Float,
    val textColorHex: String,
    val strokeColorHex: String,
    val strokeWidthDp: Float,
    val maskColorHex: String,
    val maskStyle: String,
    val alignment: String
)

data class PageWithRegions(
    @Embedded val page: PageEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "pageId"
    )
    val regions: List<TextRegionEntity>
)

data class ProjectWithPages(
    @Embedded val project: ProjectEntity,
    @Relation(
        entity = PageEntity::class,
        parentColumn = "id",
        entityColumn = "projectId"
    )
    val pages: List<PageWithRegions>
)

fun TextRegionEntity.toDomain(): TextRegion = TextRegion(
    id = id,
    pageId = pageId,
    ymin = ymin,
    xmin = xmin,
    ymax = ymax,
    xmax = xmax,
    originalText = originalText,
    translatedText = translatedText,
    regionType = RegionType.fromId(regionType),
    fontChoice = CanvasFont.fromId(fontChoice),
    fontSizeSp = fontSizeSp,
    textColorHex = textColorHex,
    strokeColorHex = strokeColorHex,
    strokeWidthDp = strokeWidthDp,
    maskColorHex = maskColorHex,
    maskStyle = MaskStyle.fromId(maskStyle),
    alignment = BoxAlignment.fromId(alignment)
)

fun TextRegion.toEntity(): TextRegionEntity = TextRegionEntity(
    id = id,
    pageId = pageId,
    ymin = ymin,
    xmin = xmin,
    ymax = ymax,
    xmax = xmax,
    originalText = originalText,
    translatedText = translatedText,
    regionType = regionType.id,
    fontChoice = fontChoice.id,
    fontSizeSp = fontSizeSp,
    textColorHex = textColorHex,
    strokeColorHex = strokeColorHex,
    strokeWidthDp = strokeWidthDp,
    maskColorHex = maskColorHex,
    maskStyle = maskStyle.id,
    alignment = alignment.id
)

fun PageWithRegions.toDomain(): PageItem = PageItem(
    id = page.id,
    projectId = page.projectId,
    pageIndex = page.pageIndex,
    sourceImagePath = page.sourceImagePath,
    width = page.width,
    height = page.height,
    status = PageStatus.fromId(page.status),
    modelUsed = page.modelUsed,
    contextSummary = page.contextSummary,
    errorMessage = page.errorMessage,
    regions = regions.map { it.toDomain() }
)

fun ProjectWithPages.toDomain(): TranslationProject = TranslationProject(
    id = project.id,
    title = project.title,
    sourceLanguage = SourceLanguage.fromCode(project.sourceLanguage),
    translationMode = TranslationMode.fromId(project.translationMode),
    glossaryNotes = project.glossaryNotes,
    createdAt = project.createdAt,
    updatedAt = project.updatedAt,
    pages = pages.sortedBy { it.page.pageIndex }.map { it.toDomain() }
)
