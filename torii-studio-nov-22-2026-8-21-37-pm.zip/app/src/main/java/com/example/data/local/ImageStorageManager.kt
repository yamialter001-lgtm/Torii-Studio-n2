package com.example.data.local

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.toColorInt
import com.example.domain.model.BoxAlignment
import com.example.domain.model.MaskStyle
import com.example.domain.model.PageItem
import com.example.domain.model.TextRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class ImportedImageResult(
    val filePath: String,
    val width: Int,
    val height: Int
)

class ImageStorageManager(private val context: Context) {

    private val pagesDir: File by lazy {
        File(context.filesDir, "manga_pages").apply { mkdirs() }
    }

    suspend fun importImageFromUri(uri: Uri): ImportedImageResult = withContext(Dispatchers.IO) {
        val orientation = context.contentResolver.openInputStream(uri)?.use { stream ->
            runCatching {
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, bounds)
        }

        val sampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, 2600, 2600)
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }

        val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: error("ไม่สามารถอ่านไฟล์รูปภาพที่เลือกได้")

        val orientedBitmap = applyExifOrientation(rawBitmap, orientation)
        if (orientedBitmap !== rawBitmap) {
            rawBitmap.recycle()
        }

        val file = File(pagesDir, "page_${UUID.randomUUID()}.jpg")
        FileOutputStream(file).use { out ->
            orientedBitmap.compress(Bitmap.CompressFormat.JPEG, 94, out)
        }
        val width = orientedBitmap.width
        val height = orientedBitmap.height
        orientedBitmap.recycle()

        ImportedImageResult(
            filePath = file.absolutePath,
            width = width,
            height = height
        )
    }

    suspend fun encodeBitmapForGemini(filePath: String, maxDimension: Int = 1600): ByteArray =
        withContext(Dispatchers.Default) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(filePath, bounds)
            val sampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxDimension, maxDimension)
            val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = BitmapFactory.decodeFile(filePath, opts)
                ?: error("ไม่พบไฟล์รูปภาพต้นฉบับ")

            val scaled = scaleDownIfNeeded(decoded, maxDimension)
            if (scaled !== decoded) decoded.recycle()

            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 88, baos)
            scaled.recycle()
            baos.toByteArray()
        }

    suspend fun renderAndSaveTranslatedPage(
        page: PageItem,
        outputBaseName: String
    ): String = withContext(Dispatchers.Default) {
        val baseBitmap = BitmapFactory.decodeFile(page.sourceImagePath)
            ?.copy(Bitmap.Config.ARGB_8888, true)
            ?: error("ไม่สามารถโหลดภาพต้นฉบับเพื่อบันทึกได้")

        val canvas = Canvas(baseBitmap)
        val imgW = baseBitmap.width.toFloat()
        val imgH = baseBitmap.height.toFloat()

        // Scale factor from preview logical dp (~360dp width) to full image pixels
        val densityScale = imgW / 360f

        page.regions.forEach { region ->
            drawRegionOnCanvas(canvas, region, imgW, imgH, densityScale)
        }

        val fileName = "${outputBaseName}_${page.pageIndex + 1}.png"
        val savedLocation = saveBitmapToGalleryOrAppDir(baseBitmap, fileName)
        baseBitmap.recycle()
        savedLocation
    }

    fun deleteImageFile(path: String) {
        runCatching { File(path).delete() }
    }

    private fun drawRegionOnCanvas(
        canvas: Canvas,
        region: TextRegion,
        imgW: Float,
        imgH: Float,
        densityScale: Float
    ) {
        val left = (region.xmin.coerceIn(0f, 1000f) / 1000f) * imgW
        val top = (region.ymin.coerceIn(0f, 1000f) / 1000f) * imgH
        val right = (region.xmax.coerceIn(0f, 1000f) / 1000f) * imgW
        val bottom = (region.ymax.coerceIn(0f, 1000f) / 1000f) * imgH
        if (right <= left || bottom <= top) return

        val boxWidth = (right - left).coerceAtLeast(24f)
        val boxHeight = (bottom - top).coerceAtLeast(24f)
        val rect = RectF(left, top, right, bottom)
        val cornerRadius = (minOf(boxWidth, boxHeight) * 0.22f).coerceAtMost(24f * densityScale)

        val maskColor = safeParseColor(region.maskColorHex, Color.WHITE)
        when (region.maskStyle) {
            MaskStyle.SOLID_FILL -> {
                val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = maskColor
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(rect, cornerRadius, cornerRadius, fillPaint)
            }
            MaskStyle.SOFT_BLUR -> {
                val pad = 4f * densityScale
                val expanded = RectF(
                    (left - pad).coerceAtLeast(0f),
                    (top - pad).coerceAtLeast(0f),
                    (right + pad).coerceAtMost(imgW),
                    (bottom + pad).coerceAtMost(imgH)
                )
                val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = maskColor
                    style = Paint.Style.FILL
                    maskFilter = BlurMaskFilter((6f * densityScale).coerceAtLeast(1f), BlurMaskFilter.Blur.NORMAL)
                }
                canvas.drawRoundRect(expanded, cornerRadius, cornerRadius, blurPaint)
            }
            MaskStyle.TRANSPARENT -> Unit
        }

        val text = region.translatedText.trim()
        if (text.isEmpty()) return

        val typeface: Typeface = ResourcesCompat.getFont(context, region.fontChoice.fontRes)
            ?: Typeface.DEFAULT

        val textAlignment = when (region.alignment) {
            BoxAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            BoxAlignment.START -> Layout.Alignment.ALIGN_NORMAL
            BoxAlignment.END -> Layout.Alignment.ALIGN_OPPOSITE
        }

        val horizontalPadding = (boxWidth * 0.06f).coerceAtLeast(4f * densityScale)
        val availableWidth = (boxWidth - horizontalPadding * 2f).toInt().coerceAtLeast(16)
        val availableHeight = (boxHeight * 0.94f).toInt().coerceAtLeast(16)

        // Auto-fit font size down gently if text overflows box height, starting from user's chosen fontSizeSp
        var textSizePx = (region.fontSizeSp * densityScale).coerceAtLeast(10f)
        val minTextSizePx = (8f * densityScale).coerceAtLeast(8f)

        val fillTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            color = safeParseColor(region.textColorHex, Color.BLACK)
            textSize = textSizePx
        }

        var layout = buildStaticLayout(text, fillTextPaint, availableWidth, textAlignment)
        while (layout.height > availableHeight && textSizePx > minTextSizePx) {
            textSizePx = (textSizePx * 0.9f).coerceAtLeast(minTextSizePx)
            fillTextPaint.textSize = textSizePx
            layout = buildStaticLayout(text, fillTextPaint, availableWidth, textAlignment)
        }

        val offsetY = top + ((boxHeight - layout.height) / 2f).coerceAtLeast(0f)
        val offsetX = left + horizontalPadding

        canvas.save()
        canvas.translate(offsetX, offsetY)

        if (region.strokeWidthDp > 0.1f) {
            val strokeTextPaint = TextPaint(fillTextPaint).apply {
                style = Paint.Style.STROKE
                strokeJoin = Paint.Join.ROUND
                strokeCap = Paint.Cap.ROUND
                strokeWidth = region.strokeWidthDp * densityScale * 1.4f
                color = safeParseColor(region.strokeColorHex, Color.WHITE)
            }
            val strokeLayout = buildStaticLayout(text, strokeTextPaint, availableWidth, textAlignment)
            strokeLayout.draw(canvas)
        }

        layout.draw(canvas)
        canvas.restore()
    }

    private fun buildStaticLayout(
        text: String,
        paint: TextPaint,
        width: Int,
        alignment: Layout.Alignment
    ): StaticLayout {
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(alignment)
            .setLineSpacing(0f, 1.08f)
            .setIncludePad(false)
            .build()
    }

    private suspend fun saveBitmapToGalleryOrAppDir(bitmap: Bitmap, fileName: String): String =
        withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_PICTURES}/ToriiStudioTH"
                    )
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("ไม่สามารถสร้างไฟล์ในแกลเลอรีได้")
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                } ?: error("ไม่สามารถเขียนข้อมูลภาพลงแกลเลอรีได้")

                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                "Pictures/ToriiStudioTH/$fileName"
            } else {
                val outDir = File(
                    context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                    "ToriiStudioTH"
                ).apply { mkdirs() }
                val outFile = File(outDir, fileName)
                FileOutputStream(outFile).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                outFile.absolutePath
            }
        }

    private fun safeParseColor(hex: String, fallback: Int): Int {
        return runCatching { hex.trim().toColorInt() }.getOrDefault(fallback)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun calculateInSampleSize(
        width: Int,
        height: Int,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / maxSide.toFloat()
        val targetW = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetH = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }
}
