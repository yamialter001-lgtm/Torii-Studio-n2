package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AppPreferences
import com.example.domain.model.CanvasFont
import com.example.domain.model.SourceLanguage
import com.example.domain.model.ThemeMode
import com.example.domain.model.TranslationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "torii_studio_prefs"
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DEFAULT_FONT = stringPreferencesKey("default_font")
        val DEFAULT_SOURCE_LANG = stringPreferencesKey("default_source_lang")
        val DEFAULT_TRANSLATION_MODE = stringPreferencesKey("default_translation_mode")
        val AUTO_FALLBACK_ENABLED = booleanPreferencesKey("auto_fallback_enabled")
        val CUSTOM_GLOSSARY = stringPreferencesKey("custom_glossary")
    }

    val preferencesFlow: Flow<AppPreferences> = context.studioDataStore.data.map { prefs ->
        AppPreferences(
            geminiApiKey = prefs[Keys.GEMINI_API_KEY].orEmpty(),
            themeMode = ThemeMode.fromId(prefs[Keys.THEME_MODE] ?: ThemeMode.DARK.id),
            defaultFont = CanvasFont.fromId(prefs[Keys.DEFAULT_FONT] ?: CanvasFont.ITIM.id),
            defaultSourceLanguage = SourceLanguage.fromCode(
                prefs[Keys.DEFAULT_SOURCE_LANG] ?: SourceLanguage.AUTO.code
            ),
            defaultTranslationMode = TranslationMode.fromId(
                prefs[Keys.DEFAULT_TRANSLATION_MODE] ?: TranslationMode.MANGA.id
            ),
            autoFallbackEnabled = prefs[Keys.AUTO_FALLBACK_ENABLED] ?: true,
            customGlossary = prefs[Keys.CUSTOM_GLOSSARY].orEmpty()
        )
    }

    suspend fun saveGeminiApiKey(apiKey: String) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.GEMINI_API_KEY] = apiKey.trim()
        }
    }

    suspend fun saveThemeMode(themeMode: ThemeMode) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = themeMode.id
        }
    }

    suspend fun saveDefaultFont(font: CanvasFont) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_FONT] = font.id
        }
    }

    suspend fun saveDefaultSourceLanguage(language: SourceLanguage) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_SOURCE_LANG] = language.code
        }
    }

    suspend fun saveDefaultTranslationMode(mode: TranslationMode) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_TRANSLATION_MODE] = mode.id
        }
    }

    suspend fun saveAutoFallback(enabled: Boolean) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.AUTO_FALLBACK_ENABLED] = enabled
        }
    }

    suspend fun saveCustomGlossary(glossary: String) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.CUSTOM_GLOSSARY] = glossary.trim()
        }
    }
}
