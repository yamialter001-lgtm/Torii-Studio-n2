package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.ImageStorageManager
import com.example.data.local.LocalProjectRepository
import com.example.data.local.PreferencesRepository
import com.example.data.remote.GeminiException
import com.example.data.remote.GeminiTranslationRepository
import com.example.domain.model.AppPreferences
import com.example.domain.model.CanvasFont
import com.example.domain.model.GeminiModels
import com.example.domain.model.PageItem
import com.example.domain.model.PageStatus
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TextRegion
import com.example.domain.model.TranslationMode
import com.example.domain.model.TranslationProject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CompareMode {
    OFF,
    SPLIT_SLIDER
}

data class BatchProgressState(
    val currentNumber: Int,
    val totalCount: Int,
    val activeModel: String,
    val usedFallbackAny: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class StudioViewModel(
    private val projectRepository: LocalProjectRepository,
    private val geminiRepository: GeminiTranslationRepository,
    private val preferencesRepository: PreferencesRepository,
    private val imageStorage: ImageStorageManager
) : ViewModel() {

    val projects: StateFlow<List<TranslationProject>> = projectRepository.observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeProjectId = MutableStateFlow<Long?>(null)

    val activeProject: StateFlow<TranslationProject?> = combine(
        _activeProjectId,
        projects
    ) { selectedId, allProjects ->
        selectedId ?: allProjects.firstOrNull()?.id
    }.flatMapLatest { resolvedId ->
        if (resolvedId == null) flowOf(null) else projectRepository.observeProject(resolvedId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _activePageIndex = MutableStateFlow(0)
    val activePageIndex: StateFlow<Int> = _activePageIndex.asStateFlow()

    val activePage: StateFlow<PageItem?> = combine(
        activeProject,
        _activePageIndex
    ) { project, idx ->
        val pages = project?.pages.orEmpty()
        if (pages.isEmpty()) null else pages[idx.coerceIn(0, pages.lastIndex)]
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedRegionId = MutableStateFlow<Long?>(null)
    val selectedRegionId: StateFlow<Long?> = _selectedRegionId.asStateFlow()

    private val _transientRegionEdit = MutableStateFlow<TextRegion?>(null)
    val transientRegionEdit: StateFlow<TextRegion?> = _transientRegionEdit.asStateFlow()

    private val _compareMode = MutableStateFlow(CompareMode.OFF)
    val compareMode: StateFlow<CompareMode> = _compareMode.asStateFlow()

    private val _splitRatio = MutableStateFlow(0.5f)
    val splitRatio: StateFlow<Float> = _splitRatio.asStateFlow()

    private val _isHoldingOriginal = MutableStateFlow(false)
    val isHoldingOriginal: StateFlow<Boolean> = _isHoldingOriginal.asStateFlow()

    private val _batchProgress = MutableStateFlow<BatchProgressState?>(null)
    val batchProgress: StateFlow<BatchProgressState?> = _batchProgress.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _events = MutableSharedFlow<StudioEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<StudioEvent> = _events.asSharedFlow()

    private var translationJob: Job? = null

    fun importImages(uris: List<Uri>, appendToCurrent: Boolean = false) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val prefs: AppPreferences = preferencesRepository.preferencesFlow.first()
                val currentProj = activeProject.value
                if (appendToCurrent && currentProj != null) {
                    val startIdx = currentProj.pages.size
                    projectRepository.appendImagesToProject(currentProj.id, startIdx, uris)
                    _activePageIndex.value = startIdx
                    _selectedRegionId.value = null
                    _events.tryEmit(StudioEvent.Message("เพิ่ม ${uris.size} ภาพเข้าชุดแปลปัจจุบันแล้ว"))
                } else {
                    val stamp = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
                    val title = if (uris.size > 1) "ชุดแปล ${uris.size} หน้า ($stamp)" else "ภาพแปล ($stamp)"
                    val newId = projectRepository.createProjectWithImages(
                        title = title,
                        sourceLanguage = prefs.defaultSourceLanguage,
                        translationMode = prefs.defaultTranslationMode,
                        glossaryNotes = prefs.customGlossary,
                        uris = uris
                    )
                    _activeProjectId.value = newId
                    _activePageIndex.value = 0
                    _selectedRegionId.value = null
                    _compareMode.value = CompareMode.OFF
                    _events.tryEmit(StudioEvent.Message("นำเข้า ${uris.size} ภาพเรียบร้อย พร้อมแปล"))
                }
            } catch (e: Exception) {
                _events.tryEmit(StudioEvent.Message("นำเข้าภาพไม่สำเร็จ: ${e.localizedMessage}"))
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun selectProject(projectId: Long) {
        _activeProjectId.value = projectId
        _activePageIndex.value = 0
        _selectedRegionId.value = null
        _compareMode.value = CompareMode.OFF
    }

    fun deleteProject(project: TranslationProject) {
        viewModelScope.launch {
            if (_activeProjectId.value == project.id) {
                _activeProjectId.value = null
            }
            projectRepository.deleteProject(project)
            _selectedRegionId.value = null
            _events.tryEmit(StudioEvent.Message("ลบชุดแปล \"${project.title}\" แล้ว"))
        }
    }

    fun selectPage(index: Int) {
        _activePageIndex.value = index
        _selectedRegionId.value = null
        _transientRegionEdit.value = null
    }

    fun updateProjectLanguage(language: SourceLanguage) {
        val proj = activeProject.value ?: return
        viewModelScope.launch {
            projectRepository.updateProjectConfig(proj.id, language, proj.translationMode)
        }
    }

    fun updateProjectMode(mode: TranslationMode) {
        val proj = activeProject.value ?: return
        viewModelScope.launch {
            projectRepository.updateProjectConfig(proj.id, proj.sourceLanguage, mode)
        }
    }

    fun toggleSplitCompare() {
        _compareMode.value = if (_compareMode.value == CompareMode.SPLIT_SLIDER) {
            CompareMode.OFF
        } else {
            _selectedRegionId.value = null
            CompareMode.SPLIT_SLIDER
        }
    }

    fun setSplitRatio(ratio: Float) {
        _splitRatio.value = ratio.coerceIn(0.05f, 0.95f)
    }

    fun setHoldOriginal(holding: Boolean) {
        _isHoldingOriginal.value = holding
    }

    fun translateCurrentPage(forcedModel: String? = null) {
        val project = activeProject.value ?: return
        val page = activePage.value ?: return

        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            if (prefs.geminiApiKey.isBlank()) {
                _events.tryEmit(StudioEvent.RequireApiKey)
                return@launch
            }

            _selectedRegionId.value = null
            _compareMode.value = CompareMode.OFF
            val previousSummary = project.pages
                .getOrNull((page.pageIndex - 1).coerceAtLeast(0))
                ?.takeIf { page.pageIndex > 0 }
                ?.contextSummary

            runSinglePageTranslation(
                project = project,
                page = page,
                prefs = prefs,
                previousContext = previousSummary,
                forcedModel = forcedModel,
                pageNumberInBatch = 1,
                totalBatch = 1
            )
            _batchProgress.value = null
        }
    }

    fun translateBatch(retranslateAll: Boolean = false) {
        val project = activeProject.value ?: return
        val targetPages = if (retranslateAll) {
            project.pages
        } else {
            project.pages.filter { it.status != PageStatus.DONE }
                .ifEmpty { project.pages }
        }
        if (targetPages.isEmpty()) return

        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            if (prefs.geminiApiKey.isBlank()) {
                _events.tryEmit(StudioEvent.RequireApiKey)
                return@launch
            }

            _selectedRegionId.value = null
            _compareMode.value = CompareMode.OFF

            var runningContext: String? = null
            var fallbackTriggered = false
            var successCount = 0

            targetPages.forEachIndexed { idx, page ->
                _activePageIndex.value = page.pageIndex
                val ok = runSinglePageTranslation(
                    project = project,
                    page = page,
                    prefs = prefs,
                    previousContext = runningContext,
                    forcedModel = null,
                    pageNumberInBatch = idx + 1,
                    totalBatch = targetPages.size
                )
                if (ok != null) {
                    successCount++
                    if (ok.second) fallbackTriggered = true
                    runningContext = ok.first ?: runningContext
                }
            }

            _batchProgress.value = null
            val fallbackText = if (fallbackTriggered) " (ใช้โมเดลสำรอง 3.8-flash ในบางหน้า)" else ""
            _events.tryEmit(
                StudioEvent.Message("แปลเสร็จ $successCount/${targetPages.size} หน้า$fallbackText")
            )
        }
    }

    fun cancelTranslation() {
        translationJob?.cancel()
        translationJob = null
        _batchProgress.value = null
        _events.tryEmit(StudioEvent.Message("ยกเลิกการแปลแล้ว"))
    }

    private suspend fun runSinglePageTranslation(
        project: TranslationProject,
        page: PageItem,
        prefs: AppPreferences,
        previousContext: String?,
        forcedModel: String?,
        pageNumberInBatch: Int,
        totalBatch: Int
    ): Pair<String?, Boolean>? {
        val initialModel = forcedModel ?: GeminiModels.PRIMARY
        _batchProgress.value = BatchProgressState(
            currentNumber = pageNumberInBatch,
            totalCount = totalBatch,
            activeModel = initialModel
        )
        projectRepository.markPageTranslating(page.id)

        return try {
            val result = geminiRepository.translatePage(
                apiKey = prefs.geminiApiKey,
                imagePath = page.sourceImagePath,
                pageId = page.id,
                sourceLanguage = project.sourceLanguage,
                translationMode = project.translationMode,
                defaultFont = prefs.defaultFont,
                customGlossary = prefs.customGlossary.ifBlank { project.glossaryNotes },
                previousPageContext = previousContext,
                autoFallbackEnabled = prefs.autoFallbackEnabled,
                forcedModel = forcedModel
            )
            projectRepository.savePageTranslationSuccess(
                projectId = project.id,
                pageId = page.id,
                modelUsed = result.modelUsed,
                contextSummary = result.contextSummary,
                regions = result.regions
            )
            if (result.usedFallback) {
                _batchProgress.value = _batchProgress.value?.copy(
                    activeModel = result.modelUsed,
                    usedFallbackAny = true
                )
            }
            if (totalBatch == 1) {
                val msg = if (result.usedFallback) {
                    "แปลด้วยโมเดลสำรอง ${result.modelUsed} (${result.regions.size} ช่อง)"
                } else {
                    "แปลเสร็จแล้วด้วย ${result.modelUsed} (${result.regions.size} ช่อง)"
                }
                _events.tryEmit(StudioEvent.Message(msg))
            }
            result.contextSummary to result.usedFallback
        } catch (e: CancellationException) {
            projectRepository.savePageTranslationError(page.id, "ถูกยกเลิก")
            throw e
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "แปลภาพไม่สำเร็จ"
            projectRepository.savePageTranslationError(page.id, errMsg)
            if ((e as? GeminiException)?.isAuthError == true) {
                _events.tryEmit(StudioEvent.RequireApiKey)
            } else {
                _events.tryEmit(StudioEvent.Message(errMsg))
            }
            null
        }
    }

    fun selectRegion(regionId: Long?) {
        _selectedRegionId.value = regionId
        _transientRegionEdit.value = null
        if (regionId != null && _compareMode.value == CompareMode.SPLIT_SLIDER) {
            _compareMode.value = CompareMode.OFF
        }
    }

    fun previewTransientRegion(region: TextRegion) {
        _transientRegionEdit.value = region
    }

    fun commitTransientRegion(region: TextRegion) {
        _transientRegionEdit.value = null
        updateRegion(region)
    }

    fun updateRegion(region: TextRegion) {
        viewModelScope.launch {
            projectRepository.updateRegion(region)
        }
    }

    fun applyFontToCurrentPage(font: CanvasFont) {
        val page = activePage.value ?: return
        viewModelScope.launch {
            projectRepository.applyFontToPage(page.id, font)
            _events.tryEmit(StudioEvent.Message("เปลี่ยนฟอนต์ทั้งหน้าเป็น ${font.displayName} แล้ว"))
        }
    }

    fun addManualRegion() {
        val page = activePage.value ?: return
        viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()
            val newId = projectRepository.addRegion(
                TextRegion(
                    pageId = page.id,
                    ymin = 380f,
                    xmin = 250f,
                    ymax = 520f,
                    xmax = 750f,
                    originalText = "",
                    translatedText = "ข้อความใหม่",
                    fontChoice = prefs.defaultFont,
                    fontSizeSp = 16f
                )
            )
            _selectedRegionId.value = newId
        }
    }

    fun deleteSelectedRegion() {
        val regionId = _selectedRegionId.value ?: return
        viewModelScope.launch {
            projectRepository.deleteRegion(regionId)
            _selectedRegionId.value = null
            _transientRegionEdit.value = null
        }
    }

    fun exportCurrentPage() {
        val page = activePage.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val baseName = "ToriiTH_${System.currentTimeMillis() / 1000}"
                val path = imageStorage.renderAndSaveTranslatedPage(page, baseName)
                _events.tryEmit(StudioEvent.Message("บันทึกภาพแล้ว: $path"))
            } catch (e: Exception) {
                _events.tryEmit(StudioEvent.Message("บันทึกภาพไม่สำเร็จ: ${e.localizedMessage}"))
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun exportAllPages() {
        val project = activeProject.value ?: return
        val pages = project.pages
        if (pages.isEmpty()) return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val baseName = "ToriiBatch_${System.currentTimeMillis() / 1000}"
                var count = 0
                pages.forEach { page ->
                    imageStorage.renderAndSaveTranslatedPage(page, baseName)
                    count++
                }
                _events.tryEmit(StudioEvent.Message("บันทึกทั้งชุด $count ภาพไปยัง Pictures/ToriiStudioTH แล้ว"))
            } catch (e: Exception) {
                _events.tryEmit(StudioEvent.Message("บันทึกภาพชุดไม่สำเร็จ: ${e.localizedMessage}"))
            } finally {
                _isBusy.value = false
            }
        }
    }

    class Factory(
        private val projectRepository: LocalProjectRepository,
        private val geminiRepository: GeminiTranslationRepository,
        private val preferencesRepository: PreferencesRepository,
        private val imageStorage: ImageStorageManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return StudioViewModel(
                projectRepository,
                geminiRepository,
                preferencesRepository,
                imageStorage
            ) as T
        }
    }
}

sealed interface StudioEvent {
    data class Message(val text: String) : StudioEvent
    data object RequireApiKey : StudioEvent
}
