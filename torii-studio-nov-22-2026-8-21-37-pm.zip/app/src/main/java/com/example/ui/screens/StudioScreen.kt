package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LibraryAddCheck
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.GeminiModels
import com.example.domain.model.PageItem
import com.example.domain.model.PageStatus
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TranslationMode
import com.example.ui.components.BatchFilmstrip
import com.example.ui.components.BubbleInspectorSheet
import com.example.ui.components.MangaCanvasView
import com.example.ui.components.ProjectHistorySheet
import com.example.ui.components.SettingsModal
import com.example.ui.viewmodel.CompareMode
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.StudioEvent
import com.example.ui.viewmodel.StudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
    studioViewModel: StudioViewModel,
    settingsViewModel: SettingsViewModel
) {
    val projects by studioViewModel.projects.collectAsStateWithLifecycle()
    val activeProject by studioViewModel.activeProject.collectAsStateWithLifecycle()
    val activePageIndex by studioViewModel.activePageIndex.collectAsStateWithLifecycle()
    val activePage by studioViewModel.activePage.collectAsStateWithLifecycle()
    val selectedRegionId by studioViewModel.selectedRegionId.collectAsStateWithLifecycle()
    val transientRegionEdit by studioViewModel.transientRegionEdit.collectAsStateWithLifecycle()
    val compareMode by studioViewModel.compareMode.collectAsStateWithLifecycle()
    val splitRatio by studioViewModel.splitRatio.collectAsStateWithLifecycle()
    val isHoldingOriginal by studioViewModel.isHoldingOriginal.collectAsStateWithLifecycle()
    val batchProgress by studioViewModel.batchProgress.collectAsStateWithLifecycle()
    val isBusy by studioViewModel.isBusy.collectAsStateWithLifecycle()

    val preferences by settingsViewModel.preferences.collectAsStateWithLifecycle()
    val keyTestState by settingsViewModel.keyTestState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showSettingsModal by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }
    var showLanguageMenu by remember { mutableStateOf(false) }
    var showMoreActionsMenu by remember { mutableStateOf(false) }

    val newBatchPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 30)
    ) { uris ->
        if (uris.isNotEmpty()) {
            studioViewModel.importImages(uris, appendToCurrent = false)
        }
    }

    val appendBatchPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 30)
    ) { uris ->
        if (uris.isNotEmpty()) {
            studioViewModel.importImages(uris, appendToCurrent = true)
        }
    }

    LaunchedEffect(Unit) {
        studioViewModel.events.collect { event ->
            when (event) {
                is StudioEvent.Message -> snackbarHostState.showSnackbar(event.text)
                StudioEvent.RequireApiKey -> {
                    showSettingsModal = true
                    snackbarHostState.showSnackbar("กรุณากรอก Gemini API Key เพื่อเริ่มแปลภาพ")
                }
            }
        }
    }

    // Back button closes bubble inspector first before exiting
    BackHandler(enabled = selectedRegionId != null) {
        studioViewModel.selectRegion(null)
    }

    val selectedRegion = remember(activePage, selectedRegionId, transientRegionEdit) {
        val base = activePage?.regions?.firstOrNull { it.id == selectedRegionId }
        if (base != null && transientRegionEdit?.id == base.id) transientRegionEdit else base
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(16.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Torii Studio",
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val subtitle = activePage?.modelUsed?.let { used ->
                                if (used == GeminiModels.FALLBACK) "สำรอง: $used" else "หลัก: $used"
                            } ?: "แปลภาพเป็นไทย • ${GeminiModels.PRIMARY}"
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            newBatchPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("top_import_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = stringResource(R.string.cd_import_images)
                        )
                    }
                    IconButton(
                        onClick = { showHistorySheet = true },
                        modifier = Modifier.testTag("history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "ประวัติงานแปล"
                        )
                    }
                    IconButton(
                        onClick = { showSettingsModal = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = stringResource(R.string.cd_settings),
                            tint = if (preferences.geminiApiKey.isBlank()) {
                                MaterialTheme.colorScheme.secondary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // API key reminder banner when unconfigured
            if (preferences.geminiApiKey.isBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showSettingsModal = true }
                        .testTag("missing_key_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "แตะเพื่อใส่ Gemini API Key ของคุณ (ไม่ต้องล็อกอิน)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Batch translation progress bar
            batchProgress?.let { progress ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "กำลังแปลหน้า ${progress.currentNumber}/${progress.totalCount} (${progress.activeModel})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            IconButton(
                                onClick = { studioViewModel.cancelTranslation() },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "ยกเลิกการแปล",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = {
                                progress.currentNumber.toFloat() / progress.totalCount.coerceAtLeast(1)
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            val currentProject = activeProject
            val currentPage = activePage

            if (currentProject == null || currentPage == null) {
                EmptyStudioLanding(
                    hasApiKey = preferences.geminiApiKey.isNotBlank(),
                    onImportImages = {
                        newBatchPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onOpenSettings = { showSettingsModal = true },
                    onOpenHistory = if (projects.isNotEmpty()) { { showHistorySheet = true } } else null,
                    modifier = Modifier.weight(1f)
                )
            } else {
                // Config bar: Source Language, Mode, and Quick Tools
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box {
                            AssistChip(
                                onClick = { showLanguageMenu = true },
                                label = { Text("${currentProject.sourceLanguage.shortLabel} → ไทย") },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Translate,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("language_selector_chip")
                            )
                            DropdownMenu(
                                expanded = showLanguageMenu,
                                onDismissRequest = { showLanguageMenu = false }
                            ) {
                                SourceLanguage.entries.forEach { lang ->
                                    DropdownMenuItem(
                                        text = { Text("${lang.labelTh} → ภาษาไทย") },
                                        onClick = {
                                            studioViewModel.updateProjectLanguage(lang)
                                            showLanguageMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        AssistChip(
                            onClick = {
                                val nextMode = if (currentProject.translationMode == TranslationMode.MANGA) {
                                    TranslationMode.GENERAL
                                } else {
                                    TranslationMode.MANGA
                                }
                                studioViewModel.updateProjectMode(nextMode)
                            },
                            label = { Text(currentProject.translationMode.labelTh) },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.AutoFixHigh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("mode_toggle_chip")
                        )

                        // Hold to peek original
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isHoldingOriginal) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            modifier = Modifier
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            studioViewModel.setHoldOriginal(true)
                                            tryAwaitRelease()
                                            studioViewModel.setHoldOriginal(false)
                                        }
                                    )
                                }
                                .testTag("hold_original_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    Icons.Default.Visibility,
                                    contentDescription = "กดค้างดูต้นฉบับ",
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("กดค้างดูต้นฉบับ", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        AssistChip(
                            onClick = { studioViewModel.toggleSplitCompare() },
                            label = {
                                Text(
                                    if (compareMode == CompareMode.SPLIT_SLIDER) "ปิดตัวเทียบสไลด์" else "เทียบสไลด์"
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.Compare,
                                    contentDescription = stringResource(R.string.cd_compare_before_after),
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("split_compare_chip")
                        )

                        Box {
                            IconButton(
                                onClick = { showMoreActionsMenu = true },
                                modifier = Modifier.testTag("more_canvas_actions")
                            ) {
                                Icon(Icons.Default.MoreVert, contentDescription = "เครื่องมือเพิ่มเติม")
                            }
                            DropdownMenu(
                                expanded = showMoreActionsMenu,
                                onDismissRequest = { showMoreActionsMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("เพิ่มกล่องข้อความเอง") },
                                    leadingIcon = { Icon(Icons.Default.AddBox, contentDescription = null) },
                                    onClick = {
                                        showMoreActionsMenu = false
                                        studioViewModel.addManualRegion()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("แปลซ้ำด้วยโมเดลสำรอง (${GeminiModels.FALLBACK})") },
                                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                                    onClick = {
                                        showMoreActionsMenu = false
                                        studioViewModel.translateCurrentPage(forcedModel = GeminiModels.FALLBACK)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("บันทึกภาพทั้งหมด (${currentProject.pages.size} หน้า)") },
                                    leadingIcon = { Icon(Icons.Default.LibraryAddCheck, contentDescription = null) },
                                    onClick = {
                                        showMoreActionsMenu = false
                                        studioViewModel.exportAllPages()
                                    }
                                )
                            }
                        }
                    }
                }

                // Error banner if current page failed
                if (currentPage.status == PageStatus.ERROR && !currentPage.errorMessage.isNullOrBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = currentPage.errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                // Adaptive Workspace Area
                BoxWithConstraints(modifier = Modifier.weight(1f)) {
                    val isWideScreen = maxWidth >= 720.dp

                    if (isWideScreen) {
                        Row(modifier = Modifier.fillMaxSize()) {
                            BatchFilmstrip(
                                pages = currentProject.pages,
                                activeIndex = activePageIndex,
                                vertical = true,
                                onSelectPage = studioViewModel::selectPage,
                                onAddMoreImages = {
                                    appendBatchPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .background(MaterialTheme.colorScheme.surface)
                            )

                            MangaCanvasView(
                                page = currentPage,
                                selectedRegionId = selectedRegionId,
                                transientRegionEdit = transientRegionEdit,
                                compareMode = compareMode,
                                splitRatio = splitRatio,
                                isHoldingOriginal = isHoldingOriginal,
                                onSelectRegion = studioViewModel::selectRegion,
                                onPreviewTransientRegion = studioViewModel::previewTransientRegion,
                                onCommitTransientRegion = studioViewModel::commitTransientRegion,
                                onSplitRatioChange = studioViewModel::setSplitRatio,
                                modifier = Modifier.weight(1f)
                            )

                            if (selectedRegion != null) {
                                BubbleInspectorSheet(
                                    region = selectedRegion,
                                    onUpdateRegion = studioViewModel::updateRegion,
                                    onApplyFontToPage = studioViewModel::applyFontToCurrentPage,
                                    onDeleteRegion = studioViewModel::deleteSelectedRegion,
                                    onClose = { studioViewModel.selectRegion(null) },
                                    modifier = Modifier
                                        .width(340.dp)
                                        .fillMaxHeight()
                                )
                            }
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                MangaCanvasView(
                                    page = currentPage,
                                    selectedRegionId = selectedRegionId,
                                    transientRegionEdit = transientRegionEdit,
                                    compareMode = compareMode,
                                    splitRatio = splitRatio,
                                    isHoldingOriginal = isHoldingOriginal,
                                    onSelectRegion = studioViewModel::selectRegion,
                                    onPreviewTransientRegion = studioViewModel::previewTransientRegion,
                                    onCommitTransientRegion = studioViewModel::commitTransientRegion,
                                    onSplitRatioChange = studioViewModel::setSplitRatio,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                )

                                BatchFilmstrip(
                                    pages = currentProject.pages,
                                    activeIndex = activePageIndex,
                                    vertical = false,
                                    onSelectPage = studioViewModel::selectPage,
                                    onAddMoreImages = {
                                        appendBatchPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface)
                                )
                            }

                            this@Column.AnimatedVisibility(
                                visible = selectedRegion != null,
                                enter = slideInVertically(animationSpec = spring()) { it },
                                exit = slideOutVertically(animationSpec = spring()) { it },
                                modifier = Modifier.align(Alignment.BottomCenter)
                            ) {
                                selectedRegion?.let { region ->
                                    BubbleInspectorSheet(
                                        region = region,
                                        onUpdateRegion = studioViewModel::updateRegion,
                                        onApplyFontToPage = studioViewModel::applyFontToCurrentPage,
                                        onDeleteRegion = studioViewModel::deleteSelectedRegion,
                                        onClose = { studioViewModel.selectRegion(null) },
                                        modifier = Modifier.height(370.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Bottom Action Dock
                StudioActionDock(
                    currentPage = currentPage,
                    totalPages = currentProject.pages.size,
                    isTranslating = batchProgress != null,
                    isBusy = isBusy,
                    onTranslatePage = { studioViewModel.translateCurrentPage() },
                    onTranslateBatch = { studioViewModel.translateBatch(retranslateAll = false) },
                    onExportPage = { studioViewModel.exportCurrentPage() }
                )
            }
        }
    }

    if (showSettingsModal) {
        SettingsModal(
            preferences = preferences,
            keyTestState = keyTestState,
            onSaveAndTestApiKey = settingsViewModel::saveAndTestApiKey,
            onSaveApiKeyOnly = { key ->
                settingsViewModel.saveApiKeyOnly(key)
                showSettingsModal = false
            },
            onSelectThemeMode = settingsViewModel::setThemeMode,
            onSelectDefaultFont = settingsViewModel::setDefaultFont,
            onSelectDefaultLanguage = settingsViewModel::setDefaultSourceLanguage,
            onSelectDefaultMode = settingsViewModel::setDefaultTranslationMode,
            onToggleAutoFallback = settingsViewModel::setAutoFallback,
            onSaveGlossary = settingsViewModel::setCustomGlossary,
            onDismiss = {
                settingsViewModel.resetKeyTestState()
                showSettingsModal = false
            }
        )
    }

    if (showHistorySheet) {
        ProjectHistorySheet(
            projects = projects,
            activeProjectId = activeProject?.id,
            onSelectProject = studioViewModel::selectProject,
            onDeleteProject = studioViewModel::deleteProject,
            onDismiss = { showHistorySheet = false }
        )
    }
}

@Composable
private fun StudioActionDock(
    currentPage: PageItem,
    totalPages: Int,
    isTranslating: Boolean,
    isBusy: Boolean,
    onTranslatePage: () -> Unit,
    onTranslateBatch: () -> Unit,
    onExportPage: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onTranslatePage,
                enabled = !isTranslating && !isBusy,
                modifier = Modifier
                    .weight(1f)
                    .testTag("translate_page_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (currentPage.status == PageStatus.DONE) "แปลหน้านี้ใหม่" else "แปลหน้านี้",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (totalPages > 1) {
                FilledTonalButton(
                    onClick = onTranslateBatch,
                    enabled = !isTranslating && !isBusy,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("translate_batch_button")
                ) {
                    Text(
                        text = "แปลทั้งชุด ($totalPages)",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            OutlinedButton(
                onClick = onExportPage,
                enabled = !isTranslating && !isBusy,
                modifier = Modifier.testTag("export_page_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = stringResource(R.string.cd_export_image),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text("บันทึก")
            }
        }
    }
}

@Composable
private fun EmptyStudioLanding(
    hasApiKey: Boolean,
    onImportImages: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.widthIn(max = 500.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_studio_empty),
                contentDescription = "ภาพประกอบสตูดิโอแปลมังงะ",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(20.dp))
            )

            Text(
                text = "แปลมังงะและภาพเป็นภาษาไทย",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )

            Text(
                text = "รองรับ ญี่ปุ่น • อังกฤษ • เกาหลี • จีนตัวเต็ม • จีนตัวย่อ\nวางคำแปลลงในบับเบิลด้วยฟอนต์ Itim, Kodchasan และ FiraGO พร้อมแก้ไขและบันทึกภาพความละเอียดสูง",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = onImportImages,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("empty_import_button")
            ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("เลือกรูปภาพ (เดี่ยว หรือ หลายหน้า)")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("empty_settings_button")
                ) {
                    Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (hasApiKey) "ตั้งค่า API / ธีม" else "ใส่ API Key ก่อน")
                }

                if (onOpenHistory != null) {
                    OutlinedButton(
                        onClick = onOpenHistory,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("empty_history_button")
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("งานที่เคยแปล")
                    }
                }
            }
        }
    }
}
