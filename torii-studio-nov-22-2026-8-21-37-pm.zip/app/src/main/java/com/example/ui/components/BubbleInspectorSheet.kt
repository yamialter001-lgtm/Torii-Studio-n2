package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.toColorInt
import com.example.R
import com.example.domain.model.BoxAlignment
import com.example.domain.model.CanvasFont
import com.example.domain.model.MaskStyle
import com.example.domain.model.TextRegion
import com.example.ui.theme.toFontFamily
import kotlin.math.roundToInt

private val TEXT_SWATCHES = listOf("#111318", "#FFFFFF", "#FF5A36", "#FFB84D", "#2563EB", "#DC2626")
private val MASK_SWATCHES = listOf("#FFFFFF", "#111318", "#FAF8F5", "#FFE4E6", "#E0F2FE")

@Composable
fun BubbleInspectorSheet(
    region: TextRegion,
    onUpdateRegion: (TextRegion) -> Unit,
    onApplyFontToPage: (CanvasFont) -> Unit,
    onDeleteRegion: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 12.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = region.regionType.labelTh,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = "ปรับแต่งข้อความและบับเบิล",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onDeleteRegion,
                        modifier = Modifier.testTag("delete_bubble_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = stringResource(R.string.cd_delete_text_box),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("close_inspector_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = stringResource(R.string.cd_close_inspector)
                        )
                    }
                }
            }

            if (region.originalText.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ต้นฉบับ: ${region.originalText}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            OutlinedTextField(
                value = region.translatedText,
                onValueChange = { onUpdateRegion(region.copy(translatedText = it)) },
                label = { Text("คำแปลภาษาไทย") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bubble_text_input")
            )

            // Font family selector (Itim, Kodchasan, FiraGO)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ฟอนต์ (Font)", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(
                        onClick = { onApplyFontToPage(region.fontChoice) },
                        modifier = Modifier.testTag("apply_font_page_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text("ใช้ ${region.fontChoice.displayName} ทั้งหน้า", style = MaterialTheme.typography.labelMedium)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CanvasFont.entries.forEach { font ->
                        val selected = region.fontChoice == font
                        FilterChip(
                            selected = selected,
                            onClick = { onUpdateRegion(region.copy(fontChoice = font)) },
                            label = {
                                Text(
                                    text = font.displayName,
                                    fontFamily = font.toFontFamily(),
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("font_chip_${font.id}")
                        )
                    }
                }
            }

            // Font size & stroke width sliders
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ขนาด: ${region.fontSizeSp.roundToInt()} sp",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Slider(
                        value = region.fontSizeSp,
                        onValueChange = { onUpdateRegion(region.copy(fontSizeSp = it)) },
                        valueRange = 9f..36f,
                        modifier = Modifier.testTag("font_size_slider")
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ขอบตัวอักษร: ${"%.1f".format(region.strokeWidthDp)}",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Slider(
                        value = region.strokeWidthDp,
                        onValueChange = { onUpdateRegion(region.copy(strokeWidthDp = it)) },
                        valueRange = 0f..6f,
                        modifier = Modifier.testTag("stroke_width_slider")
                    )
                }
            }

            // Alignment & Mask style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    AlignmentIconBtn(
                        selected = region.alignment == BoxAlignment.START,
                        icon = Icons.AutoMirrored.Filled.FormatAlignLeft,
                        desc = "ชิดซ้าย",
                        onClick = { onUpdateRegion(region.copy(alignment = BoxAlignment.START)) }
                    )
                    AlignmentIconBtn(
                        selected = region.alignment == BoxAlignment.CENTER,
                        icon = Icons.Default.FormatAlignCenter,
                        desc = "กึ่งกลาง",
                        onClick = { onUpdateRegion(region.copy(alignment = BoxAlignment.CENTER)) }
                    )
                    AlignmentIconBtn(
                        selected = region.alignment == BoxAlignment.END,
                        icon = Icons.AutoMirrored.Filled.FormatAlignRight,
                        desc = "ชิดขวา",
                        onClick = { onUpdateRegion(region.copy(alignment = BoxAlignment.END)) }
                    )
                }

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MaskStyle.entries.forEach { mask ->
                        FilterChip(
                            selected = region.maskStyle == mask,
                            onClick = { onUpdateRegion(region.copy(maskStyle = mask)) },
                            label = { Text(mask.labelTh, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Color swatches (Text + Bubble Fill)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("สีข้อความ", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TEXT_SWATCHES.forEach { hex ->
                            ColorDot(
                                hex = hex,
                                selected = region.textColorHex.equals(hex, ignoreCase = true),
                                onClick = {
                                    val autoStroke = if (hex.equals("#FFFFFF", true)) "#111318" else "#FFFFFF"
                                    onUpdateRegion(region.copy(textColorHex = hex, strokeColorHex = autoStroke))
                                }
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("สีพื้นบับเบิล", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MASK_SWATCHES.forEach { hex ->
                            ColorDot(
                                hex = hex,
                                selected = region.maskColorHex.equals(hex, ignoreCase = true),
                                onClick = { onUpdateRegion(region.copy(maskColorHex = hex)) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
private fun AlignmentIconBtn(
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = desc,
                tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ColorDot(
    hex: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val color = Color(hex.toColorInt())
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 2.5.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                shape = CircleShape
            )
            .clickable(onClick = onClick)
    )
}
