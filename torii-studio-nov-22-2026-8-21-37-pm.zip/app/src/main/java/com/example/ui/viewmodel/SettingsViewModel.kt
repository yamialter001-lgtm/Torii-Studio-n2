package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.PreferencesRepository
import com.example.data.remote.GeminiTranslationRepository
import com.example.data.remote.KeyValidationResult
import com.example.domain.model.AppPreferences
import com.example.domain.model.CanvasFont
import com.example.domain.model.SourceLanguage
import com.example.domain.model.ThemeMode
import com.example.domain.model.TranslationMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface KeyTestUiState {
    data object Idle : KeyTestUiState
    data object Testing : KeyTestUiState
    data class Success(val verifiedModel: String) : KeyTestUiState
    data class Failure(val errorMessage: String) : KeyTestUiState
}

class SettingsViewModel(
    private val preferencesRepository: PreferencesRepository,
    private val geminiRepository: GeminiTranslationRepository
) : ViewModel() {

    val preferences: StateFlow<AppPreferences> = preferencesRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppPreferences()
        )

    private val _keyTestState = MutableStateFlow<KeyTestUiState>(KeyTestUiState.Idle)
    val keyTestState: StateFlow<KeyTestUiState> = _keyTestState.asStateFlow()

    fun saveAndTestApiKey(apiKey: String) {
        val trimmed = apiKey.trim()
        viewModelScope.launch {
            preferencesRepository.saveGeminiApiKey(trimmed)
            if (trimmed.isEmpty()) {
                _keyTestState.value = KeyTestUiState.Failure("กรุณากรอก Gemini API Key")
                return@launch
            }
            _keyTestState.value = KeyTestUiState.Testing
            when (val result = geminiRepository.validateApiKey(trimmed)) {
                is KeyValidationResult.Valid -> {
                    _keyTestState.value = KeyTestUiState.Success(result.modelVerified)
                }
                is KeyValidationResult.Invalid -> {
                    _keyTestState.value = KeyTestUiState.Failure(result.message)
                }
            }
        }
    }

    fun saveApiKeyOnly(apiKey: String) {
        viewModelScope.launch {
            preferencesRepository.saveGeminiApiKey(apiKey.trim())
            _keyTestState.value = KeyTestUiState.Idle
        }
    }

    fun resetKeyTestState() {
        _keyTestState.value = KeyTestUiState.Idle
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.saveThemeMode(mode) }
    }

    fun setDefaultFont(font: CanvasFont) {
        viewModelScope.launch { preferencesRepository.saveDefaultFont(font) }
    }

    fun setDefaultSourceLanguage(language: SourceLanguage) {
        viewModelScope.launch { preferencesRepository.saveDefaultSourceLanguage(language) }
    }

    fun setDefaultTranslationMode(mode: TranslationMode) {
        viewModelScope.launch { preferencesRepository.saveDefaultTranslationMode(mode) }
    }

    fun setAutoFallback(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.saveAutoFallback(enabled) }
    }

    fun setCustomGlossary(glossary: String) {
        viewModelScope.launch { preferencesRepository.saveCustomGlossary(glossary) }
    }

    class Factory(
        private val preferencesRepository: PreferencesRepository,
        private val geminiRepository: GeminiTranslationRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(preferencesRepository, geminiRepository) as T
        }
    }
}
