package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.AppPreferences
import com.example.domain.model.CanvasFont
import com.example.domain.model.GeminiModels
import com.example.domain.model.SourceLanguage
import com.example.domain.model.ThemeMode
import com.example.domain.model.TranslationMode
import com.example.ui.theme.toFontFamily
import com.example.ui.viewmodel.KeyTestUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsModal(
    preferences: AppPreferences,
    keyTestState: KeyTestUiState,
    onSaveAndTestApiKey: (String) -> Unit,
    onSaveApiKeyOnly: (String) -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onSelectDefaultFont: (CanvasFont) -> Unit,
    onSelectDefaultLanguage: (SourceLanguage) -> Unit,
    onSelectDefaultMode: (TranslationMode) -> Unit,
    onToggleAutoFallback: (Boolean) -> Unit,
    onSaveGlossary: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current

    var apiKeyInput by remember(preferences.geminiApiKey) { mutableStateOf(preferences.geminiApiKey) }
    var showKey by remember { mutableStateOf(false) }
    var glossaryInput by remember(preferences.customGlossary) { mutableStateOf(preferences.customGlossary) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ตั้งค่า API และรูปแบบสตูดิโอ",
                    style = MaterialTheme.typography.titleLarge
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "ปิดหน้าตั้งค่า")
                }
            }

            // Section 1: BYOK Gemini API Key
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Gemini API Key ส่วนตัว",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Text(
                        text = "คีย์จะถูกบันทึกไว้ในเครื่องของคุณเท่านั้น ไม่มีการล็อกอินหรือส่งออกภายนอก",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text("วาง Gemini API Key (AIza...)") },
                        singleLine = true,
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row {
                                IconButton(onClick = {
                                    clipboard.getText()?.text?.let { pasted ->
                                        apiKeyInput = pasted.trim()
                                    }
                                }) {
                                    Icon(Icons.Default.ContentPaste, contentDescription = "วางจากคลิปบอร์ด")
                                }
                                IconButton(onClick = { showKey = !showKey }) {
                                    Icon(
                                        imageVector = if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showKey) "ซ่อนคีย์" else "แสดงคีย์"
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onSaveAndTestApiKey(apiKeyInput) },
                            enabled = keyTestState !is KeyTestUiState.Testing,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_api_key_button")
                        ) {
                            if (keyTestState is KeyTestUiState.Testing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Text("บันทึกและทดสอบคีย์")
                        }
                        OutlinedButton(
                            onClick = { onSaveApiKeyOnly(apiKeyInput) },
                            modifier = Modifier.testTag("save_api_key_button")
                        ) {
                            Text("บันทึก")
                        }
                    }

                    when (keyTestState) {
                        is KeyTestUiState.Success -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "คีย์ใช้งานได้ปกติ (ตรวจสอบผ่าน ${keyTestState.verifiedModel})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                        is KeyTestUiState.Failure -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = keyTestState.errorMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                        else -> Unit
                    }
                }
            }

            // Section 2: Model Pipeline
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("โมเดลที่ใช้ในการแปล", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "• โมเดลหลัก: ${GeminiModels.PRIMARY}\n• โมเดลสำรอง: ${GeminiModels.FALLBACK}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("สลับไปใช้โมเดลสำรองอัตโนมัติ", style = MaterialTheme.typography.labelLarge)
                            Text(
                                text = "ใช้ ${GeminiModels.FALLBACK} ทันทีหากโมเดลหลักติดลิมิตหรือล้มเหลว",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = preferences.autoFallbackEnabled,
                            onCheckedChange = onToggleAutoFallback,
                            modifier = Modifier.testTag("auto_fallback_switch")
                        )
                    }
                }
            }

            // Section 3: Theme Mode
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("โทนสีแอป (Theme)", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = preferences.themeMode == mode,
                            onClick = { onSelectThemeMode(mode) },
                            label = { Text(mode.labelTh) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("theme_chip_${mode.id}")
                        )
                    }
                }
            }

            // Section 4: Default Font
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ฟอนต์เริ่มต้นสำหรับคำแปลบนภาพ", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CanvasFont.entries.forEach { font ->
                        FilterChip(
                            selected = preferences.defaultFont == font,
                            onClick = { onSelectDefaultFont(font) },
                            label = {
                                Text(
                                    text = font.displayName,
                                    fontFamily = font.toFontFamily(),
                                    fontWeight = if (preferences.defaultFont == font) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section 5: Default Translation Mode
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("โหมดแปลเริ่มต้น", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TranslationMode.entries.forEach { mode ->
                        FilterChip(
                            selected = preferences.defaultTranslationMode == mode,
                            onClick = { onSelectDefaultMode(mode) },
                            label = { Text(mode.labelTh) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            HorizontalDivider()

            // Section 6: Custom Glossary
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("พจนานุกรมคำศัพท์ / แนวทางสรรพนาม (ไม่บังคับ)", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = glossaryInput,
                    onValueChange = { glossaryInput = it },
                    placeholder = { Text("เช่น พระเอกแทนตัวเองว่า 'ผม', ชื่อตัวละคร อาคิระ = อากิระ") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { onSaveGlossary(glossaryInput) },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("บันทึกพจนานุกรม")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
