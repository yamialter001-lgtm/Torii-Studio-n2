package com.example.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.toColorInt
import com.example.domain.model.BoxAlignment
import com.example.domain.model.MaskStyle
import com.example.domain.model.PageItem
import com.example.domain.model.PageStatus
import com.example.domain.model.TextRegion
import com.example.ui.theme.toFontFamily
import com.example.ui.viewmodel.CompareMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun MangaCanvasView(
    page: PageItem,
    selectedRegionId: Long?,
    transientRegionEdit: TextRegion?,
    compareMode: CompareMode,
    splitRatio: Float,
    isHoldingOriginal: Boolean,
    onSelectRegion: (Long?) -> Unit,
    onPreviewTransientRegion: (TextRegion) -> Unit,
    onCommitTransientRegion: (TextRegion) -> Unit,
    onSplitRatioChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var zoomScale by remember(page.id) { mutableFloatStateOf(1f) }
    var panOffset by remember(page.id) { mutableStateOf(Offset.Zero) }

    var bitmap by remember(page.sourceImagePath) {
        mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null)
    }

    LaunchedEffect(page.sourceImagePath) {
        bitmap = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(page.sourceImagePath)?.asImageBitmap()
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(page.id) {
                detectTapGestures(
                    onDoubleTap = {
                        zoomScale = if (zoomScale > 1.05f) 1f else 2f
                        panOffset = Offset.Zero
                    },
                    onTap = {
                        onSelectRegion(null)
                    }
                )
            }
            .pointerInput(page.id) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (zoomScale * zoom).coerceIn(1f, 4f)
                    zoomScale = newScale
                    if (newScale > 1.01f) {
                        val maxPanX = (size.width * (newScale - 1f)) / 2f
                        val maxPanY = (size.height * (newScale - 1f)) / 2f
                        panOffset = Offset(
                            x = (panOffset.x + pan.x).coerceIn(-maxPanX, maxPanX),
                            y = (panOffset.y + pan.y).coerceIn(-maxPanY, maxPanY)
                        )
                    } else {
                        panOffset = Offset.Zero
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val density = LocalDensity.current
        val containerW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val containerH = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        val imgW = (bitmap?.width ?: page.width).coerceAtLeast(1).toFloat()
        val imgH = (bitmap?.height ?: page.height).coerceAtLeast(1).toFloat()
        val imgAspect = imgW / imgH
        val containerAspect = containerW / containerH

        val fittedWidthPx: Float
        val fittedHeightPx: Float
        if (imgAspect > containerAspect) {
            fittedWidthPx = containerW
            fittedHeightPx = containerW / imgAspect
        } else {
            fittedHeightPx = containerH
            fittedWidthPx = containerH * imgAspect
        }

        val fittedWidthDp = with(density) { fittedWidthPx.toDp() }
        val fittedHeightDp = with(density) { fittedHeightPx.toDp() }
        val previewScale = fittedWidthDp.value / 360f

        Box(
            modifier = Modifier
                .size(fittedWidthDp, fittedHeightDp)
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
        ) {
            val loadedBitmap = bitmap
            if (loadedBitmap != null) {
                Image(
                    bitmap = loadedBitmap,
                    contentDescription = "หน้าภาพสำหรับแปลภาษา",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
            }

            // Translated Thai Regions Overlay
            if (!isHoldingOriginal && page.regions.isNotEmpty()) {
                val overlayShape = if (compareMode == CompareMode.SPLIT_SLIDER) {
                    GenericShape { size, _ ->
                        val startX = size.width * splitRatio
                        moveTo(startX, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width, size.height)
                        lineTo(startX, size.height)
                        close()
                    }
                } else {
                    RoundedCornerShape(0.dp)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(overlayShape)
                ) {
                    page.regions.forEach { storedRegion ->
                        val region = if (transientRegionEdit?.id == storedRegion.id) {
                            transientRegionEdit
                        } else {
                            storedRegion
                        }
                        val isSelected = region.id == selectedRegionId && compareMode == CompareMode.OFF

                        RegionOverlayBox(
                            region = region,
                            fittedWidthPx = fittedWidthPx,
                            fittedHeightPx = fittedHeightPx,
                            previewScale = previewScale,
                            isSelected = isSelected,
                            onSelect = { onSelectRegion(region.id) },
                            onPreviewUpdate = onPreviewTransientRegion,
                            onCommitUpdate = onCommitTransientRegion
                        )
                    }
                }
            }

            // Interactive Before/After Split Curtain Handle
            if (compareMode == CompareMode.SPLIT_SLIDER) {
                val dividerXPx = (fittedWidthPx * splitRatio).roundToInt()
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .offset { IntOffset(dividerXPx - with(density) { 24.dp.roundToPx() }, 0) }
                        .width(48.dp)
                        .testTag("split_compare_handle")
                        .pointerInput(fittedWidthPx) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val currentPx = splitRatio * fittedWidthPx + dragAmount.x
                                onSplitRatioChange(currentPx / fittedWidthPx)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(2.5.dp)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.primary)
                    )
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = "เลื่อนเปรียบเทียบก่อนและหลังแปล",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Split labels
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ComparePill("ต้นฉบับ")
                    ComparePill("แปลไทย")
                }
            }

            // Translating Shimmer Overlay
            if (page.status == PageStatus.TRANSLATING) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                        tonalElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.5.dp
                            )
                            Text(
                                text = "กำลังตรวจจับและแปลภาษา...",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        if (isHoldingOriginal) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
            ) {
                Text(
                    text = "กำลังแสดงภาพต้นฉบับ",
                    color = MaterialTheme.colorScheme.onSecondary,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun ComparePill(label: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.Black.copy(alpha = 0.65f)
    ) {
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun RegionOverlayBox(
    region: TextRegion,
    fittedWidthPx: Float,
    fittedHeightPx: Float,
    previewScale: Float,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onPreviewUpdate: (TextRegion) -> Unit,
    onCommitUpdate: (TextRegion) -> Unit
) {
    val density = LocalDensity.current
    val leftPx = (region.xmin.coerceIn(0f, 1000f) / 1000f) * fittedWidthPx
    val topPx = (region.ymin.coerceIn(0f, 1000f) / 1000f) * fittedHeightPx
    val rightPx = (region.xmax.coerceIn(0f, 1000f) / 1000f) * fittedWidthPx
    val bottomPx = (region.ymax.coerceIn(0f, 1000f) / 1000f) * fittedHeightPx

    val boxWidthDp = with(density) { (rightPx - leftPx).coerceAtLeast(24f).toDp() }
    val boxHeightDp = with(density) { (bottomPx - topPx).coerceAtLeast(20f).toDp() }
    val cornerRadius = (minOf(boxWidthDp, boxHeightDp) * 0.2f).coerceAtMost(18.dp)

    val maskColor = remember(region.maskColorHex) {
        parseColorSafe(region.maskColorHex, Color.White)
    }
    val textColor = remember(region.textColorHex) {
        parseColorSafe(region.textColorHex, Color(0xFF111318))
    }
    val strokeColor = remember(region.strokeColorHex) {
        parseColorSafe(region.strokeColorHex, Color.White)
    }

    var latestRegion by remember(region.id) { mutableStateOf(region) }
    latestRegion = region

    val backgroundModifier = when (region.maskStyle) {
        MaskStyle.SOLID_FILL -> Modifier.background(maskColor, RoundedCornerShape(cornerRadius))
        MaskStyle.SOFT_BLUR -> Modifier.background(
            brush = Brush.radialGradient(
                colors = listOf(maskColor.copy(alpha = 0.96f), maskColor.copy(alpha = 0.72f))
            ),
            shape = RoundedCornerShape(cornerRadius)
        )
        MaskStyle.TRANSPARENT -> Modifier
    }

    Box(
        modifier = Modifier
            .offset { IntOffset(leftPx.roundToInt(), topPx.roundToInt()) }
            .size(boxWidthDp, boxHeightDp)
            .then(backgroundModifier)
            .then(
                if (isSelected) {
                    Modifier.border(
                        width = 2.dp,
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(cornerRadius)
                    )
                } else {
                    Modifier
                }
            )
            .pointerInput(region.id) {
                detectTapGestures(
                    onTap = { onSelect() }
                )
            }
            .then(
                if (isSelected) {
                    Modifier.pointerInput(region.id, fittedWidthPx, fittedHeightPx) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val dxNorm = (dragAmount.x / fittedWidthPx) * 1000f
                                val dyNorm = (dragAmount.y / fittedHeightPx) * 1000f
                                val w = latestRegion.xmax - latestRegion.xmin
                                val h = latestRegion.ymax - latestRegion.ymin
                                val newXmin = (latestRegion.xmin + dxNorm).coerceIn(0f, 1000f - w)
                                val newYmin = (latestRegion.ymin + dyNorm).coerceIn(0f, 1000f - h)
                                val updated = latestRegion.copy(
                                    xmin = newXmin,
                                    ymin = newYmin,
                                    xmax = newXmin + w,
                                    ymax = newYmin + h
                                )
                                latestRegion = updated
                                onPreviewUpdate(updated)
                            },
                            onDragEnd = { onCommitUpdate(latestRegion) },
                            onDragCancel = { onCommitUpdate(latestRegion) }
                        )
                    }
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 3.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        val fontFamily = region.fontChoice.toFontFamily()
        val effectiveFontSize = (region.fontSizeSp * previewScale.coerceIn(0.65f, 1.5f)).sp
        val lineHeight = (region.fontSizeSp * previewScale.coerceIn(0.65f, 1.5f) * 1.15f).sp
        val textAlign = when (region.alignment) {
            BoxAlignment.CENTER -> TextAlign.Center
            BoxAlignment.START -> TextAlign.Start
            BoxAlignment.END -> TextAlign.End
        }

        val strokePx = with(density) { (region.strokeWidthDp * 1.3f).dp.toPx() }
        if (region.strokeWidthDp > 0.1f) {
            Text(
                text = region.translatedText,
                style = TextStyle(
                    fontFamily = fontFamily,
                    fontSize = effectiveFontSize,
                    lineHeight = lineHeight,
                    color = strokeColor,
                    textAlign = textAlign,
                    drawStyle = Stroke(
                        width = strokePx,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                ),
                overflow = TextOverflow.Clip
            )
        }

        Text(
            text = region.translatedText,
            style = TextStyle(
                fontFamily = fontFamily,
                fontSize = effectiveFontSize,
                lineHeight = lineHeight,
                color = textColor,
                textAlign = textAlign
            ),
            overflow = TextOverflow.Clip
        )

        if (isSelected) {
            // Resize handle at bottom-right corner with 48dp touch area
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 14.dp, y = 14.dp)
                    .size(48.dp)
                    .pointerInput(region.id, fittedWidthPx, fittedHeightPx) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val dxNorm = (dragAmount.x / fittedWidthPx) * 1000f
                                val dyNorm = (dragAmount.y / fittedHeightPx) * 1000f
                                val updated = latestRegion.copy(
                                    xmax = (latestRegion.xmax + dxNorm).coerceIn(latestRegion.xmin + 40f, 1000f),
                                    ymax = (latestRegion.ymax + dyNorm).coerceIn(latestRegion.ymin + 30f, 1000f)
                                )
                                latestRegion = updated
                                onPreviewUpdate(updated)
                            },
                            onDragEnd = { onCommitUpdate(latestRegion) },
                            onDragCancel = { onCommitUpdate(latestRegion) }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    shadowElevation = 4.dp,
                    modifier = Modifier.size(22.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.OpenInFull,
                            contentDescription = "ปรับขนาดกล่องข้อความ",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun parseColorSafe(hex: String, fallback: Color): Color {
    return runCatching { Color(hex.trim().toColorInt()) }.getOrDefault(fallback)
}
