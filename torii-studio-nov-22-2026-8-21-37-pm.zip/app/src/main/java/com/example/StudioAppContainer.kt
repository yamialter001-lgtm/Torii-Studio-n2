package com.example

import android.content.Context
import com.example.data.local.ImageStorageManager
import com.example.data.local.LocalProjectRepository
import com.example.data.local.PreferencesRepository
import com.example.data.local.StudioDatabase
import com.example.data.remote.GeminiTranslationRepository

class StudioAppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val database by lazy { StudioDatabase.getInstance(appContext) }

    val imageStorageManager by lazy { ImageStorageManager(appContext) }
    val preferencesRepository by lazy { PreferencesRepository(appContext) }
    val localProjectRepository by lazy {
        LocalProjectRepository(
            dao = database.studioDao(),
            imageStorage = imageStorageManager
        )
    }
    val geminiTranslationRepository by lazy {
        GeminiTranslationRepository(imageStorage = imageStorageManager)
    }
}
