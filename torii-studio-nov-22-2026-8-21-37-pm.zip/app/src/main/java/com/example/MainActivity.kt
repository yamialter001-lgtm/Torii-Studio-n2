package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.ToriiStudioTheme
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {

    private val appContainer by lazy { StudioAppContainer(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(
                factory = SettingsViewModel.Factory(
                    preferencesRepository = appContainer.preferencesRepository,
                    geminiRepository = appContainer.geminiTranslationRepository
                )
            )
            val studioViewModel: StudioViewModel = viewModel(
                factory = StudioViewModel.Factory(
                    projectRepository = appContainer.localProjectRepository,
                    geminiRepository = appContainer.geminiTranslationRepository,
                    preferencesRepository = appContainer.preferencesRepository,
                    imageStorage = appContainer.imageStorageManager
                )
            )

            val prefs by settingsViewModel.preferences.collectAsStateWithLifecycle()

            ToriiStudioTheme(themeMode = prefs.themeMode) {
                StudioScreen(
                    studioViewModel = studioViewModel,
                    settingsViewModel = settingsViewModel
                )
            }
        }
    }
}
