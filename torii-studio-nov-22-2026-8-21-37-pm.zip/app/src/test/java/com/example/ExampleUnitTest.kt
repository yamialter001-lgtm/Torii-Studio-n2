package com.example

import com.example.domain.model.CanvasFont
import com.example.domain.model.GeminiModels
import com.example.domain.model.SourceLanguage
import com.example.domain.model.TranslationMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun configured_gemini_models_and_languages_match_requirements() {
        assertEquals("gemini-3.5-flash-lite", GeminiModels.PRIMARY)
        assertEquals("gemini-3.8-flash", GeminiModels.FALLBACK)

        val expectedCodes = listOf("auto", "ja", "en", "ko", "zh-TW", "zh-CN")
        assertTrue(SourceLanguage.entries.map { it.code }.containsAll(expectedCodes))
        assertEquals(listOf("Itim", "Kodchasan", "FiraGO"), CanvasFont.entries.map { it.displayName })
        assertEquals(2, TranslationMode.entries.size)
    }
}
