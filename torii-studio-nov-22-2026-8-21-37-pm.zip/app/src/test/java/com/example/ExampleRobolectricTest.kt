package com.example

import android.content.Context
import androidx.core.content.res.ResourcesCompat
import androidx.test.core.app.ApplicationProvider
import com.example.domain.model.CanvasFont
import com.example.domain.model.GeminiModels
import com.example.domain.model.SourceLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Torii Studio`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Torii Studio", appName)
    }

    @Test
    fun `bundled fonts itim kodchasan firago load from resources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        CanvasFont.entries.forEach { font ->
            val typeface = ResourcesCompat.getFont(context, font.fontRes)
            assertNotNull("Expected typeface for ${font.displayName}", typeface)
        }
    }

    @Test
    fun `configured gemini models and source languages match spec`() {
        assertEquals("gemini-3.5-flash-lite", GeminiModels.PRIMARY)
        assertEquals("gemini-3.8-flash", GeminiModels.FALLBACK)
        val expectedCodes = listOf("auto", "ja", "en", "ko", "zh-TW", "zh-CN")
        assertTrue(SourceLanguage.entries.map { it.code }.containsAll(expectedCodes))
    }
}
